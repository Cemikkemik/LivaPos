<section class="content-header">
  <h1>
    <?php echo str_replace('&mdash; ' . get('core_signature'), '', Html::get_title());?>
    <small><?php echo Html::get_description();?></small>
  </h1>
  <!--
  <ol class="breadcrumb">
    <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
    <li class="active">Dashboard</li>
  </ol>
  -->
</section>