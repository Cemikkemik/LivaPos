<?php
return array(
	'2.0.8'			=>	function() {
	},
    '2.0.3'        =>        MODULESPATH . '/nexo_premium/migrate/2.0.3.php',
    '1.9'        =>        MODULESPATH . '/nexo_premium/migrate/1.9.php'
);
