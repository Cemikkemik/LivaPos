Tendoo-CMS 
=========
Are you looking for some handy tools to create your web applications ? Tendoo CMS is build for you.

Our purpose
===========
This repository aim to offer an easy and very handy tools to help Codeigniter developper to create website and web applications.

What's are the advantages
-------------------------
Easy way to handle CodeIgniter libraries : let assume youhave serveral libraries that you want to test on your projet. If youwere using default CodeIgniter installation, for each third libraries, you was forced to extract each files within the package to put them in the right folder, and if you wanted to remove that library, it was required for you to keep in mind all those files you wanted to remove to successfully remove that library.

Tendoo CMS offer an easy was to install those library with a module management system, which help you to install, enable, delete and share installed module easily.

The new release 3.0.5 support .po files, for better internationalization.

We also use popular classes and libraries (both JS and PHP) to create a more powerful CMS based on CodeIgniter.
We are also inspired by existing CMS (for not wasting time reinventing the wheel) and use popular API such as Plugin API from WordPress, for better performance and extensibility.

Test out our demo
-------------------------------------

You can log in to test the new branch in action.

credientials : 
email : admin@tendoo.org
password : tendoo

[Get to app settings now](http://ci3.tendoo.org/index.php/dashboard/settings?source=github)

[Get to user profile](http://ci3.tendoo.org/index.php/dashboard/profile?source=github)

[Get to module installation screen](http://ci3.tendoo.org/index.php/dashboard/modules/install_zip?source=github)

[Get to user management screen](http://ci3.tendoo.org/index.php/dashboard/users?source=github)

[Login page](http://ci3.tendoo.org/index.php/sign-in)

More a coming...



Do you want to get Involved ?
-----------------------------
Fork it a pull your new 

Sub projects merged within
-------------------------

[AdminLTE 2.1.1](https://github.com/almasaeed2010/AdminLTE)

[Assets Helper](https://github.com/sekati/codeigniter-asset-helper)

[CodeIgiter Enqueue](https://github.com/zajohnson/CodeIgniter-enqueue)

[PHP-Hooks](https://github.com/bainternet/PHP-Hooks)

[Unzip](https://github.com/philsturgeon/codeigniter-unzip/blob/master/libraries/Unzip.php)

[CI MarkDown](https://github.com/jonlabelle/ci-markdown)
