<?php
/**
 * Table Status
**/

$config[ 'nexo_restaurant_table_status' ]	=	array(
	1	=>	get_instance()->lang->line( 'nexo_restaurant_available' ),
	2	=>	get_instance()->lang->line( 'nexo_restaurant_busy' ),
	3	=>	get_instance()->lang->line( 'nexo_restaurant_unavailable' )
);