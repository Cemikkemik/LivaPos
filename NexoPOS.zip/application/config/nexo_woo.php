<?php
defined('BASEPATH') or exit('No direct script access allowed');

$config[ 'nexo_woo_url_prefix' ]				=	'SITE-URL';

$config[ 'nexo_woo_consumer_key_prefix' ]		=	'CONSUMER-KEY';

$config[ 'nexo_woo_consumer_secret_prefix' ]	=	'CONSUMER-SECRET';