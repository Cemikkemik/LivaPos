<?php if( $AnguCrud->fieldsType[ $key ] == 'datetime' ):?>

    <md-input-container>
    <label><?php echo $title;?></label>
    <md-datepicker ng-model="fields[ '<?php echo $key;?>' ]"></md-datepicker>
    </md-input-container>

<?php elseif( $AnguCrud->fieldsType[ $key ] == 'select_relation' ):?>

    <?php $matching     =   $AnguCrud->getMatching(); ?>

    <md-input-container class="md-block" flex="30">
        <label><?php echo $title;?></label>
        <md-select ng-model="fields[ '<?php echo $key;?>' ]"
                   md-on-close="resetSearchvalues()"
                   data-md-container-class="selectdemoSelectHeader">
          <md-select-header class="demo-select-header">
            <input ng-model="<?php echo $key;?>"
                   ng-init="<?php echo $key;?> = ''"
                   type="search"
                   placeholder="<?php echo $AnguCrud->searchSelectLabel;?>"
                   class="demo-header-searchbox md-text select-field">
          </md-select-header>
          <md-optgroup label="<?php echo $title;?>">
            <md-option ng-repeat="option in relationsObject[ '<?php echo $matching[ $key ];?>' ] | filter:<?php echo $key;?>" ng-value="{{ option.key }}">{{ option.value }}</md-option>
          </md-optgroup>
        </md-select>
      </md-input-container>

<?php endif;?>
