<?php 
class Meat_Actions extends Tendoo_Module 
{
    public function __construct()
    {
        parent::__construct();
    }

    public function dashboard()
    {
        $this->Gui->register_page_object( 'meat-settings', new Meat_Controller );
    }

    /**
     * Do enable module
     *
    **/

    public function enable()
    {       
        global $Options;

        $this->load->model( 'Nexo_Stores' );

        $stores         =   $this->Nexo_Stores->get();

        array_unshift( $stores, [
            'ID'        =>  0
        ]);

        if( @$Options[ 'meat-installed' ] == null ) {
            foreach( $stores as $store ) {
                $store_prefix       =   $store[ 'ID' ] == 0 ? '' : 'store_' . $store[ 'ID' ] . '_';
                $this->db->query( 'ALTER TABLE `' . $this->db->dbprefix . $store_prefix . 'nexo_articles` CHANGE `QUANTITY` `QUANTITY` FLOAT(11) NOT NULL;' );
                $this->db->query( 'ALTER TABLE `' . $this->db->dbprefix . $store_prefix . 'nexo_commandes_produits` CHANGE `QUANTITE` `QUANTITE` FLOAT(11) NOT NULL;' );
            }
        }        
    }

    /**
     * Footer
    **/

    public function footer()
    {
        $this->load->module_view( 'meat-manager', 'v2-scripts' );
    }
}