<?php
class Meat_Controller extends Tendoo_Module
{
    public function index()
    {
        $this->Gui->set_title( __( 'Meat Settings', 'meat-manager' ) );
        $this->load->module_view( 'meat-manager', 'settings' );
    }
}