<?php
class Meat_Filters extends Tendoo_Module
{
    public function __construct()
    {
        
    }
}