<?php
include_once( dirname( __FILE__ ) . '/inc/controllers.php' );
include_once( dirname( __FILE__ ) . '/inc/actions.php' );
include_once( dirname( __FILE__ ) . '/inc/filters.php' );

class Meat_Manager extends Tendoo_Module 
{
    public function __construct()
    {
        parent::__construct();
        $this->actions          =   new Meat_Actions;
        $this->filters          =   new Meat_Filters;
        
        $this->events->add_action( 'load_dashboard', [ $this->actions, 'dashboard' ] );
        $this->events->add_action( 'dashboard_footer', [ $this->actions, 'footer' ] );
        $this->events->add_action( 'do_enable_module', [ $this->actions, 'enable' ] );
    }
}

new Meat_Manager;