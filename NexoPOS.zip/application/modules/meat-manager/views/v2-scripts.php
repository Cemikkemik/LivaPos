<?php 
global $PageNow, $Options;
if( $PageNow == 'nexo/registers/__use' ) {
    ?>
<script>

	v2Checkout.displayItems			=	function( json ) {
		if( json.length > 0 ) {
			// Empty List
			$( '#filter-list' ).html( '' );

			_.each( json, function( value, key ) {

				/**
				* We test item quantity of skip that test if item is not countable.
				* value.TYPE = 0 means item is physical, = 1 means item is numerical
				* value.STATUS = 0 means item is on sale, = 1 means item is disabled
				**/

				if( ( ( parseFloat( value.QUANTITE_RESTANTE ) > 0 && value.TYPE == '1' ) || ( value.TYPE == '2' ) ) && value.STATUS == '1' ) {

					var promo_start	= moment( value.SPECIAL_PRICE_START_DATE );
					var promo_end	= moment( value.SPECIAL_PRICE_END_DATE );

					var MainPrice	= NexoAPI.ParseFloat( value.PRIX_DE_VENTE )
					var Discounted	= '';
					var CustomBackground	=	'';
					var ImagePath			=	value.APERCU == '' ? '<?php echo '../modules/nexo/images/default.png';?>'  : value.APERCU;

					if( promo_start.isBefore( v2Checkout.CartDateTime ) ) {
						if( promo_end.isSameOrAfter( v2Checkout.CartDateTime ) ) {
							MainPrice			=	NexoAPI.ParseFloat( value.PRIX_PROMOTIONEL );
							Discounted			=	'<small style="color: #999;border: solid 1px #dadada; border-radius: 5px;padding: 2px;position: absolute;box-shadow: 0px 0px 5px 1px #988f8f;top: 10px;left: 10px;z-index: 800;    background: #EEE;"><del>' + NexoAPI.DisplayMoney( NexoAPI.ParseFloat( value.PRIX_DE_VENTE ) ) + '</del></small>';
							// CustomBackground	=	'background:<?php echo $this->config->item('discounted_item_background');?>';
						}
					}

					// @since 2.7.1
					if( v2Checkout.CartShadowPriceEnabled ) {
						MainPrice			=	NexoAPI.ParseFloat( value.SHADOW_PRICE );
					}

					// style="max-height:100px;"
					// alert( value.DESIGN.length );
					var design	=	value.DESIGN.length > 15 ? '<span class="marquee_me">' + value.DESIGN + '</span>' : value.DESIGN;

					// Reshresh JSon data
					value.MAINPRICE 		=	MainPrice;

					$( '#filter-list' ).append(
						'<div class="col-lg-2 col-md-3 col-xs-6 shop-items filter-add-product noselect text-center" data-codebar="' + value.CODEBAR + '" style="' + CustomBackground + ';padding:5px; border-right: solid 1px #DEDEDE;border-bottom: solid 1px #DEDEDE;" data-design="' + value.DESIGN.toLowerCase() + '" data-category="' + value.REF_CATEGORIE + '" data-sku="' + value.SKU.toLowerCase() + '">' +
						'<img data-original="<?php echo get_store_upload_url() . '/items-images/';?>' + ImagePath + '" width="100" style="max-height:64px;" class="img-responsive img-rounded lazy">' +
						'<div class="caption text-center" style="padding:2px;overflow:hidden;"><strong class="item-grid-title">' + design + '</strong><br>' +
						'<span class="align-center">' + NexoAPI.DisplayMoney( MainPrice ) + '</span>' + Discounted +
						'</div>' +
						'</div>' );

						v2Checkout.ItemsCategories	=	_.extend( v2Checkout.ItemsCategories, _.object( [ value.REF_CATEGORIE ], [ value.NOM ] ) );
					}
				});

				this.POSItems 		=	json;

				$( '.filter-add-product' ).each( function(){
					$(this).bind( 'mouseenter', function(){
						$( this ).find( '.marquee_me' ).replaceWith( '<marquee class="marquee_me" behavior="alternate" scrollamount="4" direction="left" style="width:100%;float:left;">' + $( this ).find( '.marquee_me' ).html() + '</marquee>' );
					})
				});

				$( '.filter-add-product' ).bind( 'mouseover', function(){
					$(this).bind( 'mouseleave', function(){
						$( this ).find( '.marquee_me' ).replaceWith( '<span class="marquee_me">' + $( this ).find( '.marquee_me' ).html() + '</span>' );
					})
				});

				// Bind Categorie @since 2.7.1
				v2Checkout.bindCategoryActions();

				// Add Lazy @since 2.6.1
				$("img.lazy").lazyload({
					failure_limit : 200,
					effect : "fadeIn",
					load : function( e ){
						$( this ).removeAttr( 'width' );
					},
					container : $( '.item-list-container' )
				});

				// Bind Add to Items
				this.bindAddToItems();
				// @since 2.9.9
				this.checkItemsStock( json );
			} else {
				NexoAPI.Bootbox().alert( '<?php echo addslashes(__('Vous ne pouvez pas procéder à une vente, car aucun article n\'est disponible pour la vente.', 'nexo' ));?>' );
			}
		};

		/**
		* Empty cart item table
		*
		**/

		this.emptyCartItemTable		=	function() {
			$( '#cart-table-body' ).find( '[cart-item]' ).remove();
		};

		/**
		* Fetch Items
		* Check whether an item is available and add it to the cart items table
		* @return void
		**/

		this.fetchItem				=	function( codebar, qte_to_add, allow_increase, filter ) {

			var filters 				=	NexoAPI.events.applyFilters( 'fetch_item', [
				codebar,
				qte_to_add,
				allow_increase,
				filter
			]);

			var codebar					=	filters[0];
			var qte_to_add				=	filters[1];
			var allow_increase			=	filters[2];
			var filter					=	filters[3];

			allow_increase				=	typeof allow_increase	==	'undefined' ? true : allow_increase
			qte_to_add					=	typeof qte_to_add == 'undefined' ? 1 : qte_to_add;
			filter						=	typeof filter == 'undefined' ? 'sku-barcode' : filter;
			// For Store Feature
			var store_id				=	'<?php echo get_store_id();?>';

			$.ajax( '<?php echo site_url(array( 'rest', 'nexo', 'item' ));?>/' + codebar + '/' + filter + '?store_id=' + store_id, { // _with_meta
				success				:	function( _item ){

					/**
					 * Filter item when is loaded
					**/

					_item 			=	NexoAPI.events.applyFilters( 'item_loaded', _item );

					/**
					 * Override Add Item default Feature
					**/

					if( NexoAPI.events.applyFilters( 'override_add_item' , false ) == true ) {
						return;
					}

					v2Checkout.addOnCart( _item, codebar, qte_to_add, allow_increase, filter );
				},
				dataType			:	'json',
				error				:	function(){
					NexoAPI.Notify().error( '<?php echo addslashes(__('Une erreur s\'est produite', 'nexo'));?>', '<?php echo addslashes(__('Impossible de récupérer les données. L\'article recherché est introuvable.', 'nexo'));?>' );
				}

			});
		};

		/**
		* Fix Product Height
		**/

		this.fixHeight				=	function(){
			// Height and Width
			var headerHeight				=	parseFloat( $( '.main-header' ).outerHeight() );
			var contentHeader				=	parseFloat( $( '.content-header' ).outerHeight() );
			var contentMargin				=	parseFloat( $( '.content' ).css( 'padding-top' ) );
			var footerHeight				=	parseFloat( $( '.main-footer' ).outerHeight() );
			var tabHeight					=	parseFloat( $( '.tab-grid' ).outerHeight(true) );
			var checkoutHeader 				=	parseFloat( $( '.checkout-header' ).outerHeight() );
			var contentPaddingTop			=	parseFloat( $( '.content' ).css( 'padding-top' ) ) + 2;

			// var windowHeight				=	parseFloat( window.innerHeight < 500 ? 500 : window.innerHeight );
			if( $( '.content-wrapper' ).css( 'min-height' ) ) {
				var	wrapperHeight			=	window.innerHeight;
				wrapperHeight			-=	footerHeight;
				wrapperHeight			-= 	headerHeight; // GG
				wrapperHeight			-=	contentHeader;
				wrapperHeight			-=	contentMargin;
			} else {
				var toreduce				=	$( '.new-wrapper' ).innerHeight() - $( '.content' ).innerHeight();
				// alert( $( '.content' ).outerHeight() );
				var	wrapperHeight			=	parseFloat( $( '.new-wrapper' ).innerHeight() );
			}

			// Col 1

			var col1_paddingWrapper			=	parseFloat( $( '#cart-details-wrapper' ).css( 'margin-bottom' ) );
			var cartHeader					=	parseFloat( $( '#cart-header' ).outerHeight(true) );
			var cartTableHeader				=	parseFloat( $( '#cart-item-table-header' ).outerHeight(true) );
			var cartTableFooter				=	parseFloat( $( '#cart-details' ).outerHeight(true) );
			var cartPanel					=	parseFloat( $( '#cart-panel' ).outerHeight(true) );

			//	alert( $( '#cart-item-table-header' ).html() );

			// alert( $( '#cart-header' ).css( 'height' ) );
			// alert( col1_paddingWrapper + ' ' +  cartHeader + ' ' + cartTableHeader + ' ' + cartTableFooter + ' ' + cartPanel + ' ' + tabHeight );

			// return;

			$( '#cart-table-body' ).height( wrapperHeight - (
				contentPaddingTop
				+ cartHeader
				+ cartTableHeader
				+ cartTableFooter
				+ cartPanel
				+ col1_paddingWrapper
				+ tabHeight
				+ checkoutHeader
			) );

			// Col 2
			var categorySliderHeight		=	parseFloat( $( '.cattegory-slider' ).height() );
			var searchFieldHeight			=	parseFloat( $( '.search-field-wrapper' ).outerHeight() );
			var productListWrapper			=	parseFloat( $( '#product-list-wrapper' ).css( 'margin-bottom' ) );

			$( '.item-list-container' ).height( wrapperHeight - (
				contentPaddingTop +
				productListWrapper +
				categorySliderHeight +
				searchFieldHeight +
				tabHeight +
				checkoutHeader 
			) );

			this.paymentWindow.hideSplash();
		};

		/**
		* Filter Item
		*
		* @param string
		* @return void
		**/

		this.filterItems			=	function( content ) {
			content					=	_.toArray( content );
			if( content.length > 0 ) {
				$( '#product-list-wrapper' ).find( '[data-category]' ).hide();
				_.each( content, function( value, key ){
					$( '#product-list-wrapper' ).find( '[data-category="' + value + '"]' ).show();
				});
			} else {
				$( '#product-list-wrapper' ).find( '[data-category]' ).show();
			}
		}

		/**
		* Get Items
		**/

		this.getItems				=	function( beforeCallback, afterCallback){
			$.ajax('<?php echo $this->events->apply_filters( 'nexo_checkout_item_url', site_url([ 'rest', 'nexo', 'item', store_get_param( '?' ) ]) );?>', { // _with_meta
				beforeSend	:	function(){
					if( typeof beforeCallback == 'function' ) {
						beforeCallback();
					}
				},
				error	:	function(){
					NexoAPI.Bootbox().alert( '<?php echo addslashes(__('Une erreur s\'est produite durant la récupération des produits', 'nexo'));?>' );
				},
				success: function( content ){
					$( this.ItemsListSplash ).hide();
					$( this.ProductListWrapper ).find( '.box-body' ).css({'visibility' :'visible' });

					v2Checkout.displayItems( content );

					if( typeof afterCallback == 'function' ) {
						afterCallback();
					}
				},
				dataType:"json"
			});
		};

		/**
		* Get Item
		* get item from cart
		**/

		this.getItem				=	function( barcode ) {
			for( var i = 0; i < this.CartItems.length ; i++ ) {
				if( this.CartItems[i].CODEBAR == barcode ) {
					return this.CartItems[i];
				}
			}
			return false;
		}

		/**
		* Get Item Sale Price
		* @param object item
		* @return float main item price
		**/

		this.getItemSalePrice			=	function( itemObj ) {
			var promo_start				= 	moment( itemObj.SPECIAL_PRICE_START_DATE );
			var promo_end				= 	moment( itemObj.SPECIAL_PRICE_END_DATE );

			var MainPrice				= 	NexoAPI.ParseFloat( itemObj.PRIX_DE_VENTE )
			var Discounted				= 	'';
			var CustomBackground		=	'';
			itemObj.PROMO_ENABLED	=	false;

			if( promo_start.isBefore( v2Checkout.CartDateTime ) ) {
				if( promo_end.isSameOrAfter( v2Checkout.CartDateTime ) ) {
					itemObj.PROMO_ENABLED	=	true;
					MainPrice				=	NexoAPI.ParseFloat( itemObj.PRIX_PROMOTIONEL );
				}
			}

			// @since 2.7.1
			if( v2Checkout.CartShadowPriceEnabled ) {
				MainPrice			=	NexoAPI.ParseFloat( itemObj.SHADOW_PRICE );
			}
			return MainPrice;
		}

		/**
		* Init Cart Date
		*
		**/

		this.initCartDateTime		=	function(){
			this.CartDateTime			=	moment( '<?php echo date_now();?>' );
			$( '.content-header h1' ).append( '<small class="pull-right" id="cart-date" style="display:none;line-height: 30px;"></small>' );

			setInterval( function(){
				v2Checkout.CartDateTime.add( 1, 's' );
				// YYYY-MM-DD
				$( '#cart-date' ).html( v2Checkout.CartDateTime.format( 'HH:mm:ss' ) );
			},1000 );

			setTimeout( function(){
				$( '#cart-date' ).show( 500 );
			}, 1000 );
		};

		/**
		* Is Cart empty
		* @return boolean
		**/

		this.isCartEmpty			=	function(){
			if( _.toArray( this.CartItems ).length > 0 ) {
				return false;
			}
			return true;
		}

		/**
		* Display item Settings
		* this option let you select categories to displays
		**/

		this.itemsSettings					=	function(){
			this.buildItemsCategories( '.categories_dom_wrapper' );
		};

		/**
		* Show Numpad
		**/

		this.showNumPad				=	function( object, text, object_wrapper, real_time ){
			// Field
			var field				=	real_time == true ? object : '[name="numpad_field"]';

			// If real time editing is enabled
			var input_field			=	! real_time ?
			'<div class="form-group">' +
			'<input type="text" class="form-control input-lg" name="numpad_field"/>' +
			'</div>' : '';

			var NumPad				=
			'<div id="numpad">' +
			'<h4 class="text-center">' + ( text ? text : '' ) + '</h4><br>' +
			input_field	+
			'<div class="row">' +
			'<div class="col-lg-3 col-md-3 col-xs-3">' +
			'<input type="button" class="btn btn-default btn-block btn-lg numpad numpad7" value="<?php echo addslashes(__('7', 'nexo'));?>"/>' +
			'</div>' +
			'<div class="col-lg-3 col-md-3 col-xs-3">' +
			'<input type="button" class="btn btn-default btn-block btn-lg numpad numpad8" value="<?php echo addslashes(__('8', 'nexo'));?>"/>' +
			'</div>' +
			'<div class="col-lg-3 col-md-3 col-xs-3">' +
			'<input type="button" class="btn btn-default btn-block btn-lg numpad numpad9" value="<?php echo addslashes(__('9', 'nexo'));?>"/>' +
			'</div>' +
			'<div class="col-lg-3 col-md-3 col-xs-3">' +
			'<input type="button" class="btn btn-default btn-block btn-lg numpad numpadplus" value="<?php echo addslashes(__('+', 'nexo'));?>"/>' +
			'</div>' +
			'</div>' +
			'<br>'+
			'<div class="row">' +
			'<div class="col-lg-3 col-md-3 col-xs-3">' +
			'<input type="button" class="btn btn-default btn-block btn-lg numpad numpad4" value="<?php echo addslashes(__('4', 'nexo'));?>"/>' +
			'</div>' +
			'<div class="col-lg-3 col-md-3 col-xs-3">' +
			'<input type="button" class="btn btn-default btn-block btn-lg numpad numpad5" value="<?php echo addslashes(__('5', 'nexo'));?>"/>' +
			'</div>' +
			'<div class="col-lg-3 col-md-3 col-xs-3">' +
			'<input type="button" class="btn btn-default btn-block btn-lg numpad numpad6" value="<?php echo addslashes(__('6', 'nexo'));?>"/>' +
			'</div>' +
			'<div class="col-lg-3 col-md-3 col-xs-3">' +
			'<input type="button" class="btn btn-default btn-block btn-lg numpad numpadminus" value="<?php echo addslashes(__('-', 'nexo'));?>"/>' +
			'</div>' +
			'</div>' +
			'<br>'+
			'<div class="row">' +
			'<div class="col-lg-3 col-md-3 col-xs-3">' +
			'<input type="button" class="btn btn-default btn-block btn-lg numpad numpad1" value="<?php echo addslashes(__('1', 'nexo'));?>"/>' +
			'</div>' +
			'<div class="col-lg-3 col-md-3 col-xs-3">' +
			'<input type="button" class="btn btn-default btn-block btn-lg numpad numpad2" value="<?php echo addslashes(__('2', 'nexo'));?>"/>' +
			'</div>' +
			'<div class="col-lg-3 col-md-3 col-xs-3">' +
			'<input type="button" class="btn btn-default btn-block btn-lg numpad numpad3" value="<?php echo addslashes(__('3', 'nexo'));?>"/>' +
			'</div>' +
			'<div class="col-lg-3 col-md-3 col-xs-3">' +
			'<input type="button" class="btn btn-warning btn-block btn-lg numpad numpaddel" value="&larr;"/>' +
			'</div>' +
			'</div>' +
			'<br/>' +
			'<div class="row">' +
			'<div class="col-lg-6 col-md-6 col-xs-6">' +
			'<input type="button" class="btn btn-default btn-block btn-lg numpad numpad0" value="<?php echo addslashes(__('0', 'nexo'));?>"/>' +
			'</div>' +
			'<div class="col-lg-3 col-md-3 col-xs-3">' +
			'<input type="button" class="btn btn-default btn-block btn-lg numpad numpaddot" value="<?php echo addslashes(__('.', 'nexo'));?>"/>' +
			'</div>' +
			'<div class="col-lg-3 col-md-3 col-xs-3">' +
			'<button type="button" class="btn btn-danger btn-block btn-lg numpad numpadclear"><i class="fa fa-eraser"></i></button></div>' +
			'</div>' +
			'</div>'
			'</div>';

			if( $( object_wrapper ).length > 0 ) {
				$( object_wrapper ).html( NumPad );
			} else {
				NexoAPI.Bootbox().confirm( NumPad, function( action ) {
					if( action == true ) {
						$( object ).val( $( field ).val() );
						$( object ).trigger( 'change' );
					}
				});
			}

			if( $( field ).val() == '' ) {
				$( field ).val(0);
			}

			$( field ).focus();

			$( field ).click(function () {
			   $(this).select();
			});

			$( field ).val( $( object ).val() );

			for( var i = 0; i <= 9; i++ ) {
				$( '#numpad' ).find( '.numpad' + i ).bind( 'click', function(){
					var current_value	=	$( field ).val();
					current_value	=	current_value == '0' ? '' : current_value;
					$( field ).val( current_value + $( this ).val() );
				});
			}

			$( '.numpadclear' ).bind( 'click', function(){
				$( field ).val(0);
			});

			$( '.numpadplus' ).bind( 'click', function(){
				var numpad_value	=	NexoAPI.ParseFloat( $( field ).val() );
				$( field ).val( ++numpad_value );
			});

			$( '.numpadminus' ).bind( 'click', function(){
				var numpad_value	=	NexoAPI.ParseFloat( $( field ).val() );
				$( field ).val( --numpad_value );
			});

			$( '.numpaddot' ).bind( 'click', function(){
				var current_value	=	$( field ).val();
				current_value	=	current_value == '' ? 0 : parseFloat( current_value );
				//var numpad_value	=	NexoAPI.ParseFloat( $( field ).val() );
				$( field ).val( current_value + '.' );
			});

			$( '.numpaddel' ).bind( 'click', function(){
				var numpad_value	=	$( field ).val();
				numpad_value	=	numpad_value.substr( 0, numpad_value.length - 1 );
				numpad_value 	= 	numpad_value == '' ? 0 : numpad_value;
				$( field ).val( numpad_value );
			});

			$( field ).blur( function(){
				if( $( this ).val() == '' ) {
					$( this ).val(0);
				}
			});
		};

		/**
		* Display specific error
		**/

		this.showError				=	function( error_type ) {
			if( error_type == 'ajax_fetch' ) {
				NexoAPI.Bootbox().alert( '<?php echo addslashes(__('Une erreur s\'est produite durant la récupération des données', 'nexo'));?>' );
			}
		}

		/**
		* Search Item
		**/

		this.searchItems					=	function( value ){
			this.fetchItem( value, 1, true, 'sku-barcode' ); // 'sku-barcode'
		};

		/**
		* Quick Search Items
		* @param
		**/

		this.quickItemSearch			=	function( value ) {
			if( value.length <= 3 ) {
				$( '.filter-add-product' ).each( function(){
					$( this ).show();
					$( this ).addClass( 'item-visible' );
					$( this ).removeClass( 'item-hidden' );
					$( this ).find( '.floatting-shortcut' ).remove();
				});
			} else {
				let i 	=	1;
				$( '.filter-add-product' ).each( function(){
					// Filter Item
					if(
						$( this ).attr( 'data-design' ).search( value.toLowerCase() ) == -1 &&
						$( this ).attr( 'data-category-name' ).search( value.toLowerCase() ) == -1 &&
						$( this ).attr( 'data-codebar' ).search( value.toLowerCase() ) == -1 && // Scan, also item Barcode
						$( this ).attr( 'data-sku' ).search( value.toLowerCase() ) == -1  // Scan, also item SKU
					) {
						$( this ).hide();
						$( this ).addClass( 'item-hidden' );
						$( this ).removeClass( 'item-visible' );
					} else {
						$( this ).show();
						$( this ).addClass( 'item-visible' );
						$( this ).removeClass( 'item-hidden' );
						$( this ).find( '.caption' ).append( '<span class="floatting-shortcut">' + i + '</span>' );
						i++;
					}					
				});
			}
		}

		/**
		* Payment
		**/

		this.paymentWindow					=	new function(){
			/// Display Splash
			this.showSplash			=	function(){
				if( $( '.nexo-overlay' ).length == 0 ) {
					$( 'body' ).append( '<div class="nexo-overlay"></div>');
					$( '.nexo-overlay').css({
						'width' : '100%',
						'height' : '100%',
						'background': 'rgba(0, 0, 0, 0.5)',
						'z-index'	: 5000,
						'position' : 'absolute',
						'top'	:	0,
						'left' : 0,
						'display' : 'none'
					}).fadeIn( 500 );

					$( '.nexo-overlay' ).append( '<i class="fa fa-refresh fa-spin nexo-refresh-icon" style="color:#FFF;font-size:50px;"></i>');

					$( '.nexo-refresh-icon' ).css({
						'position' : 'absolute',
						'top'	:	'50%',
						'left' : '50%',
						'margin-top' : '-25px',
						'margin-left' : '-25px',
						'width' : '44px',
						'height' : '50px'
					})
				}
			}

			// Hide splash
			this.hideSplash			=	function(){
				$( '.nexo-overlay' ).fadeOut( 300, function(){
					$( this ).remove();
				} );
			}

			this.close				=	function(){
				$( '[data-bb-handler="cancel"]' ).trigger( 'click' );
			};
		};

		/**
		* Refresh Cart
		*
		**/

		this.refreshCart			=	function(){
			if( this.isCartEmpty() ) {
				$( '#cart-table-notice' ).show();
			} else {
				$( '#cart-table-notice' ).hide();
			}
		};

		/**
		* Refresh Cart Values
		*
		**/

		this.refreshCartValues		=	function(){

			this.calculateCartDiscount();
			this.calculateCartRistourne();
			this.calculateCartGroupDiscount();

			this.CartDiscount		=	NexoAPI.ParseFloat( this.CartRemise + this.CartRabais + this.CartRistourne + this.CartGroupDiscount );
			this.CartValueRRR		=	NexoAPI.ParseFloat( this.CartValue - this.CartDiscount );

			this.calculateCartVAT();

			this.CartToPay			=	( this.CartValueRRR + this.CartVAT );
			<?php if( in_array(strtolower(@$Options[ store_prefix() . 'nexo_currency_iso' ]), $this->config->item('nexo_supported_currency')) ) {
				?>
				this.CartToPayLong		=	numeral( this.CartToPay ).multiply(100).value();
				<?php
			} else {
				?>
				this.CartToPayLong		=	NexoAPI.Format( this.CartToPay, '0.00' );
				<?php
			};?>

			$( '#cart-value' ).html( NexoAPI.DisplayMoney( this.CartValue ) );
			$( '#cart-vat' ).html( NexoAPI.DisplayMoney( this.CartVAT ) );
			$( '#cart-discount' ).html( NexoAPI.DisplayMoney( this.CartDiscount ) );
			$( '#cart-topay' ).html( NexoAPI.DisplayMoney( this.CartToPay ) );
			
			//@since 3.0.19
			let itemsNumber 	=	0;
			_.each( this.CartItems, ( item ) => {
				itemsNumber 	+=	item.QTE_ADDED;
			});
			$( '.items-number' ).html( itemsNumber );

			NexoAPI.events.applyFilters( 'refresh_cart_values', this.CartItems );
		};

		/**
		* use saved discount (automatic discount)
		**/

		this.restoreCustomRistourne			=	function(){
			<?php if (isset($order)):?>
			<?php if (floatval($order[ 'order' ][0][ 'RISTOURNE' ]) > 0):?>
			this.CartRistourneEnabled		=	true;
			this.CartRistourneType			=	'amount';
			this.CartRistourneAmount		=	NexoAPI.ParseFloat( <?php echo floatval($order[ 'order' ][0][ 'RISTOURNE' ]);?> );
			this.CartRistourneCustomerID	=	'<?php echo $order[ 'order' ][0][ 'REF_CLIENT' ];?>';
			<?php endif;?>
			<?php endif;?>
		}

		/**
		* Restore default discount (automatic discount)
		**/

		this.restoreDefaultRistourne		=	function(){
			this.CartRistourneType			=	'<?php echo @$Options[ store_prefix() . 'discount_type' ];?>';
			this.CartRistourneAmount		=	'<?php echo @$Options[ store_prefix() . 'discount_amount' ];?>';
			this.CartRistournePercent		=	'<?php echo @$Options[ store_prefix() . 'discount_percent' ];?>';
			this.CartRistourneEnabled		=	false;
			this.CartRistourne				=	0;
		};

		/**
		* Reset Object
		**/

		this.resetCartObject			=	function(){
			this.ItemsCategories		=	new Object;
			this.CartItems				=	new Array;
			this.CustomersGroups		=	new Array;
			this.ActiveCategories		=	new Array;
			// Restore Cart item table
			this.buildCartItemTable();
			// Load Customer and groups
			this.customers.run();
			// Build Items
			this.getItems(null, function(){
				v2Checkout.hideSplash( 'right' );
			});
		};

		/**
		* Reset Cart
		**/

		this.resetCart					=	function(){

			this.CartValue				=	0;
			this.CartValueRRR			=	0;
			this.CartVAT				=	0;
			this.CartDiscount			=	0;
			this.CartToPay				=	0;
			this.CartToPayLong			=	0;
			this.CartRabais				=	0;
			this.CartTotalItems			=	0;
			this.CartRemise				=	0;
			this.CartPerceivedSum		=	0;
			this.CartCreance			=	0;
			this.CartToPayBack			=	0;
			// @since 2.9.6
			this.CartRabaisPercent		=	0;
			this.CartRistournePercent	=	0;
			this.CartRemisePercent		=	0;
			this.POSItems				=	[];


			<?php if (isset($order[ 'order' ])):?>
			this.ProcessURL				=	"<?php echo site_url(array( 'rest', 'nexo', 'order', User::id(), $order[ 'order' ][0][ 'ID' ] ));?>?store_id=<?php echo get_store_id();?>";
			this.ProcessType			=	'PUT';
			<?php else :?>
			this.ProcessURL				=	"<?php echo site_url(array( 'rest', 'nexo', 'order', User::id() ));?>?store_id=<?php echo get_store_id();?>";
			this.ProcessType			=	'POST';
			<?php endif;?>

			this.CartRemiseType			=	'';
			this.CartRemiseEnabled		=	false;
			this.CartRemisePercent		=	0;
			this.CartPaymentType		=	null;
			this.CartShadowPriceEnabled	=	<?php echo @$Options[ store_prefix() . 'nexo_enable_shadow_price' ] == 'yes' ? 'true' : 'false';?>;
			this.CartCustomerID			=	<?php echo @$Options[ store_prefix() . 'default_compte_client' ] != null ? $Options[ store_prefix() . 'default_compte_client' ] : 'null';?>;
			this.CartAllowStripeSubmitOrder	=	false;

			this.cartGroupDiscountReset();
			this.resetCartObject();
			this.restoreDefaultRistourne();
			this.refreshCartValues();

			// @since 2.7.3
			this.CartNote				=	'';

			// @since 2.9.0
			this.CartTitle				=	'';

			// @since 2.8.2
			this.CartMetas				=	{};

			// Reset Cart
			NexoAPI.events.doAction( 'reset_cart', this );
		}

		/**
		* Run Checkout
		**/

		this.run							=	function(){

			this.resetCart();
			this.initCartDateTime();
			this.bindHideItemOptions();
			// @since 2.7.3
			this.bindAddNote();

			<?php if (isset($order)):?>
			this.emptyCartItemTable();
			<?php foreach ($order[ 'products' ] as $product):?>
			this.CartItems.push( <?php echo json_encode($product);?> );
			<?php endforeach;?>

			<?php if ( ! empty( $order[ 'order' ][0][ 'REMISE_TYPE' ] ) ):?>
			this.CartRemiseType			=	'<?php echo $order[ 'order' ][0][ 'REMISE_TYPE' ];?>';
			this.CartRemise				=	NexoAPI.ParseFloat( <?php echo $order[ 'order' ][0][ 'REMISE' ];?> );
			this.CartRemisePercent		=	<?php echo $order[ 'order' ][0][ 'REMISE_PERCENT' ];?>;
			this.CartRemiseEnabled		=	true;
			<?php endif;?>

			<?php if (floatval($order[ 'order' ][0][ 'GROUP_DISCOUNT' ]) > 0):?>
			this.CartGroupDiscount				=	<?php echo floatval($order[ 'order' ][0][ 'GROUP_DISCOUNT' ]);?>; // final amount
			this.CartGroupDiscountAmount		=	<?php echo floatval($order[ 'order' ][0][ 'GROUP_DISCOUNT' ]);?>; // Amount set on each group
			this.CartGroupDiscountType			=	'amount'; // Discount type
			this.CartGroupDiscountEnabled		=	true;
			<?php endif;?>

			this.CartCustomerID					=	<?php echo $order[ 'order' ][0][ 'REF_CLIENT' ];?>;

			// @since 2.7.3
			this.CartNote						=	'<?php echo $order[ 'order'][0][ 'DESCRIPTION' ];?>';

			// @since 2.9.1
			this.CartTitle						=	'<?php echo $order[ 'order'][0][ 'TITRE' ];?>';

			// Restore Custom Ristourne
			this.restoreCustomRistourne();

			// Refresh Cart
			// Reset Cart state
			this.buildCartItemTable();
			this.refreshCart();
			this.refreshCartValues();
			<?php endif;?>

			this.CartStartAnimation			=	'<?php echo $this->config->item('nexo_cart_animation');?>';

			$( this.ProductListWrapper ).removeClass( this.CartStartAnimation ).css( 'visibility', 'visible').addClass( this.CartStartAnimation );
			$( this.CartTableWrapper ).removeClass( this.CartStartAnimation ).css( 'visibility', 'visible').addClass( this.CartStartAnimation );

			/*this.getItems(null, function(){ // ALREADY Loaded while resetting cart
			v2Checkout.hideSplash( 'right' );
		});*/

		$( this.CartCancelButton ).bind( 'click', function(){
			v2Checkout.cartCancel();
		});

		$( this.CartDiscountButton ).bind( 'click', function(){
			v2Checkout.bindAddDiscount({
				beforeLoad		:	function(){
					if( v2Checkout.CartRemiseType != null ) {
						$( '.' + v2Checkout.CartRemiseType + '_discount' ).trigger( 'click' );

						if( v2Checkout.CartRemiseType == 'percentage' ) {
							$( '[name="discount_value"]' ).val( v2Checkout.CartRemisePercent );
						} else if( v2Checkout.CartRemiseType == 'flat' ) {
							$( '[name="discount_value"]' ).val( v2Checkout.CartRemise );
						}

					} else {
						$( '.flat_discount' ).trigger( 'click' );
					}
				},
				onFixedDiscount		:	function(){
					v2Checkout.CartRemiseType	=	'flat';
				},
				onPercentDiscount	:	function(){
					v2Checkout.CartRemiseType	=	'percentage';
				},
				onFieldBlur			:	function(){
					// console.log( 'Field blur performed' );
					// Percentage allowed to 100% only
					if( v2Checkout.CartRemiseType == 'percentage' && NexoAPI.ParseFloat( $( '[name="discount_value"]' ).val() ) > 100 ) {
						$( this ).val( 100 );
					} else if( v2Checkout.CartRemiseType == 'flat' && NexoAPI.ParseFloat( $( '[name="discount_value"]' ).val() ) > v2Checkout.CartValue ) {
						// flat discount cannot exceed cart value
						$( this ).val( v2Checkout.CartValue );
						NexoAPI.Notify().info( '<?php echo _s('Attention', 'nexo');?>', '<?php echo _s('La remise fixe ne peut pas excéder la valeur actuelle du panier. Le montant de la remise à été réduite à la valeur du panier.', 'nexo');?>' );
					}
				},
				onExit				:	function( value ){

					var value	=	$( '[name="discount_value"]' ).val();

					if( value  == '' || value == '0' ) {
						NexoAPI.Bootbox().alert( '<?php echo addslashes(__('Vous devez définir un pourcentage ou une somme.', 'nexo'));?>' );
						return false;
					}

					// console.log( 'Exit discount box	' );
					// Percentage can't exceed 100%
					if( v2Checkout.CartRemiseType == 'percentage' && NexoAPI.ParseFloat( value ) > 100 ) {
						value = 100;
					} else if( v2Checkout.CartRemiseType == 'flat' && NexoAPI.ParseFloat( value ) > v2Checkout.CartValue ) {
						// flat discount cannot exceed cart value
						value	=	v2Checkout.CartValue;
					}

					$( '[name="discount_value"]' ).focus();
					$( '[name="discount_value"]' ).blur();

					v2Checkout.CartRemiseEnabled	=	true;
					v2Checkout.calculateCartDiscount( value );
					v2Checkout.refreshCartValues();
				}
			});
		});

		/**
		* Search Item Feature
		**/

		$( this.ItemSearchForm ).bind( 'submit', function(){
			v2Checkout.searchItems( $( '[name="item_sku_barcode"]' ).val() );
			$( '[name="item_sku_barcode"]' ).val('');
			return false;
		});

		$( '.enable_barcode_search' ).bind( 'click', function(){
			if( $( this ).hasClass( 'active' ) ) {
				$( this ).removeClass( 'active' );
				v2Checkout.enableBarcodeSearch 	=	false;
			} else {
				$( this ).addClass( 'active' );
				v2Checkout.enableBarcodeSearch 	=	true;
				$( '[name="item_sku_barcode"]' ).focus();
			}
		});

		// check if the button is clicked
		<?php if( @$Options[ 'enable_quick_search' ] == 'yes' ):?>
		$( '.enable_barcode_search' ).trigger( 'click' );
		<?php endif;?>

		/**
		* Filter Item
		**/

		let addItemTimeout;

		$( this.ItemSearchForm ).bind( 'keyup', function(){
			if( v2Checkout.enableBarcodeSearch == false ) {
				v2Checkout.quickItemSearch( $( '[name="item_sku_barcode"]' ).val() );
			}

			// Add found item on the cart
			// @since 3.0.19
			if( typeof this.addItemTimeout == 'undefined' ) {
				this.addItemTimeout 	=	5;
			}

			window.clearTimeout( addItemTimeout );

			addItemTimeout 	=	window.setTimeout( () => {
				if( $( '.filter-add-product.item-visible' ).length == 1 ) {
					// when i item is found, just blur the field to avoid multiple quantity adding
					$( '.filter-add-product.item-visible' ).click();
					$( '[name="item_sku_barcode"]' ).val('');
					v2Checkout.quickItemSearch( '' );
				}
			}, 500 );
		});

		/**
		* Cart Item Settings
		**/

		$( this.ItemSettings ).bind( 'click', function(){
			v2Checkout.itemsSettings();
		});

		// Bind toggle compact mode
		this.bindToggleComptactMode();

		//
		$(window).on("beforeunload", function() {
			if( ! v2Checkout.isCartEmpty() ) {
				return "<?php echo addslashes(__('Le processus de commande a commencé. Si vous continuez, vous perdrez toutes les informations non enregistrées', 'nexo'));?>";
			}
		})

		setTimeout( function(){
			v2Checkout.toggleCompactMode(true);
		}, 800 );
	}


    v2Checkout.checkItemsStock      =	function( items ) {
		var stockToReport			=	new Array;
		var minPercentage			=	<?php echo is_numeric( @$Options[ store_prefix() . 'nexo_stock_percentage_warning' ] ) ? @$Options[ store_prefix() . 'nexo_stock_percentage_warning' ] : 100;?>;
		var isEnabled				=	'<?php echo @$Options[ store_prefix() . 'nexo_enable_stock_warning' ];?>';

		if( isEnabled == 'yes' ) {

			_.each( items, function( value, key ) {
				var leftPercentage	=	( parseFloat( value.QUANTITE_RESTANTE ) * 100 ) / parseFloat( value.QUANTITY );
				if( leftPercentage <= minPercentage ) {
					stockToReport.push({
						'id'		:	value.ID,
						'design'	:	value.DESIGN
					});
				}
			});

			if( stockToReport.length > 0 ) {
				$.ajax({
					url		:	'<?php echo site_url( array( 'rest', 'nexo', 'stock_report', store_get_param( '?' ) ) );?>',
					method	:	'POST',
					data	:	{
						'reported_items'	:	stockToReport
					}
				});
			}
		}
	}

    /**
	* Build Cart Item table
	* @return void
	**/

	v2Checkout.buildCartItemTable		=	function() {
		// Empty Cart item table first
		this.emptyCartItemTable();
		this.CartValue		=	0;
		var _tempCartValue	=	0;
		this.CartTotalItems	=	0;

		if( _.toArray( this.CartItems ).length > 0 ){
			_.each( this.CartItems, function( value, key ) {

				var promo_start			= 	moment( value.SPECIAL_PRICE_START_DATE );
				var promo_end			= 	moment( value.SPECIAL_PRICE_END_DATE );

				var MainPrice			= 	NexoAPI.ParseFloat( value.PRIX_DE_VENTE )
				var Discounted			= 	'';
				var CustomBackground	=	'';
				value.PROMO_ENABLED	=	false;

				if( promo_start.isBefore( v2Checkout.CartDateTime ) ) {
					if( promo_end.isSameOrAfter( v2Checkout.CartDateTime ) ) {
						value.PROMO_ENABLED	=	true;
						MainPrice			=	NexoAPI.ParseFloat( value.PRIX_PROMOTIONEL );
						Discounted			=	'<small><del>' + NexoAPI.DisplayMoney( NexoAPI.ParseFloat( value.PRIX_DE_VENTE ) ) + '</del></small>';
						CustomBackground	=	'background:<?php echo $this->config->item('discounted_item_background');?>';
					}
				}

				// @since 2.7.1
				if( v2Checkout.CartShadowPriceEnabled ) {
					MainPrice			=	NexoAPI.ParseFloat( value.SHADOW_PRICE );
				}

				// <span class="btn btn-primary btn-xs item-reduce hidden-sm hidden-xs">-</span> <input type="number" style="width:40px;border-radius:5px;border:solid 1px #CCC;" maxlength="3"/> <span class="btn btn-primary btn-xs   hidden-sm hidden-xs">+</span>

				// <?php echo site_url('dashboard/nexo/produits/lists/edit');?>
				// /' + value.ID + '

				// :: alert( value.DESIGN.length );
				var item_design		=	NexoAPI.events.applyFilters( 'cart_item_name', {
					original 		:	value.DESIGN,
					displayed 		:	value.DESIGN
				}); // .length > 20 ? '<span style="text-overflow:hidden">' + value.DESIGN.substr( 0, 20 ) + '</span>' : value.DESIGN ;

				var DiscountAmount	=	value.DISCOUNT_TYPE	== 'percentage' ? value.DISCOUNT_PERCENT + '%' : NexoAPI.DisplayMoney( value.DISCOUNT_AMOUNT );

				var itemSubTotal	=	MainPrice * parseFloat( value.QTE_ADDED );

				if( value.DISCOUNT_TYPE == 'percentage' && parseFloat( value.DISCOUNT_PERCENT ) > 0 ) {
					var itemPercentOff	=	( itemSubTotal * parseFloat( value.DISCOUNT_PERCENT ) ) / 100;
					itemSubTotal	-=	itemPercentOff;
				} else if( value.DISCOUNT_TYPE == 'flat' && parseFloat( value.DISCOUNT_AMOUNT ) > 0 ) {
					var itemPercentOff	=	 parseFloat( value.DISCOUNT_AMOUNT );
					itemSubTotal	-=	itemPercentOff;
				}

				// <marquee class="marquee_me" behavior="alternate" scrollamount="4" direction="left" style="width:100%;float:left;">Earl Klugh - HandPucked</marquee>

				$( '#cart-table-body' ).find( 'table' ).append(
					'<tr cart-item data-line-weight="' + ( MainPrice * parseFloat( value.QTE_ADDED ) ) + '" data-item-barcode="' + value.CODEBAR + '">' +
						'<td width="200" class="text-left" style="line-height:30px;">' + NexoAPI.events.applyFilters( 'cart_before_item_name', '' ) + '<p style="text-transform: uppercase;float:left;width:76%;margin-bottom:0px;" class="item-name">' + item_design.displayed + '</p></td>' +
						'<td width="110" class="text-center item-unit-price"  style="line-height:30px;">' + NexoAPI.DisplayMoney( MainPrice ) + ' ' + Discounted + '</td>' +
						'<td width="100" class="text-center">' +
						'<div class="input-group input-group-sm">' +
						'<span class="input-group-btn">' +
							'<button class="btn btn-default item-reduce">-</button>' +
							'<button name="shop_item_quantity" value="' + value.QTE_ADDED + '" class="btn btn-default" style="width:50px;">' + value.QTE_ADDED + '</button>' +
							'<button class="btn btn-default item-add">+</button>' +
						'</span>' +
						'</td>' +
						<?php if( @$Options[ store_prefix() . 'unit_item_discount_enabled' ] == 'yes' ):?>
						'<td width="90" class="text-center item-discount"  style="line-height:28px;"><span class="btn btn-default btn-sm">' + DiscountAmount + '</span></td>' +
						<?php endif;?>
						'<td width="100" class="text-right" style="line-height:30px;">' + NexoAPI.DisplayMoney( itemSubTotal ) + '</td>' +
					'</tr>'
				);

				_tempCartValue	+=	( itemSubTotal ); // MainPrice * parseFloat( value.QTE_ADDED )

				// Just to count all products
				v2Checkout.CartTotalItems	+=	parseFloat( value.QTE_ADDED );
			});

			this.CartValue	=	_tempCartValue;

		} else {
			$( this.CartTableBody ).find( 'tbody' ).html( '<tr id="cart-table-notice"><td colspan="4"><?php _e('Veuillez ajouter un produit...', 'nexo');?></td></tr>' );
		}

		this.bindAddReduceActions();
		this.bindQuickEditItem();
		this.bindAddByInput();
		this.refreshCartValues();
		this.bindChangeUnitPrice(); // @since 2.9.0
		this.bindUnitItemDiscount();
		this.bindHoverItemName(); // @since 3.0.19

		// @since 2.7.3
		// trigger action when cart is refreshed
		NexoAPI.events.doAction( 'cart_refreshed', v2Checkout );
	}

    /**
	* Bind Add Reduce Actions on Cart table items
	**/

	v2Checkout.bindAddReduceActions	    =	function(){

		$( '#cart-table-body .item-reduce' ).each(function(){
			$( this ).bind( 'click', function(){
				
				let parent	=	$( this ).closest( 'tr' );
				
				_.each( v2Checkout.CartItems, function( value, key ) {
					if( typeof value != 'undefined' ) {
						if( value.CODEBAR == $( parent ).data( 'item-barcode' ) ) {

							let status		=	NexoAPI.events.applyFilters( 'reduce_from_cart', {
								barcode 	:	value.CODEBAR,
								item 		:	value,
								proceed 	:	true
							});

							if( status.proceed == true ) {
								value.QTE_ADDED--;
								// If item reach "0";
								if( parseFloat( value.QTE_ADDED ) == 0 ) {
									v2Checkout.CartItems.splice( key, 1 );
								}
							}							
						}
					}
				});

				// Add Item To Cart
				NexoAPI.events.doAction( 'reduce_from_cart', v2Checkout );

				v2Checkout.buildCartItemTable();
			});
		});

		$( '#cart-table-body .item-add' ).each(function(){
			$( this ).bind( 'click', function(){
				var parent	=	$( this ).closest( 'tr' );
				v2Checkout.fetchItem( $( parent ).data( 'item-barcode' ), 1, true );
			});
		});
	};

    /**
	 *  Add on cart
	 *  @param object item to fetch
	 *  @return void
	**/

	v2Checkout.addOnCart 				=	function( _item, codebar, qte_to_add, allow_increase, filter ) {

		/**
		* If Item is "On Sale"
		**/

		if( _item.length > 0 && _item[0].STATUS == '1' ) {

			var InCart				=	false;
			var InCartIndex			=	null;

			// Let's check whether an item is already added to cart
			_.each( v2Checkout.CartItems, function( value, _index ) {
				if( value.CODEBAR == _item[0].CODEBAR ) {
					InCartIndex		=	_index;
					InCart			=	true;
				}
			});

			if( InCart ) {

				// if increase is disabled, we set value
				var comparison_qte	=	allow_increase == true ? parseFloat( v2Checkout.CartItems[ InCartIndex ].QTE_ADDED ) + parseFloat( qte_to_add ) : qte_to_add;

				/**
				* 	For "Out of Stock" notice to work, item must be physical
				* 	and Stock management must be enabled
				**/

				if(
					parseFloat( _item[0].QUANTITE_RESTANTE ) - ( comparison_qte ) < 0
					&& _item[0].TYPE == '1'
					&& _item[0].STOCK_ENABLED == '1'
				) {
					NexoAPI.Notify().warning(
						'<?php echo _s( 'Une erreur s\'est produite', 'nexo' );?>',
						'<?php echo addslashes(__( 'La quantité restante du produit n\'est pas suffisante.', 'nexo' ) );?>'
					);
				} else {
					if( allow_increase ) {
						// Fix concatenation when order was edited
						v2Checkout.CartItems[ InCartIndex ].QTE_ADDED	=	parseFloat( v2Checkout.CartItems[ InCartIndex ].QTE_ADDED );
						v2Checkout.CartItems[ InCartIndex ].QTE_ADDED	+=	parseFloat( qte_to_add );
					} else {
						if( qte_to_add > 0 ){
							v2Checkout.CartItems[ InCartIndex ].QTE_ADDED	=	parseFloat( qte_to_add );
						} else {
							NexoAPI.Bootbox().confirm( '<?php echo addslashes(__('Défininr "0" comme quantité, retirera le produit du panier. Voulez-vous continuer ?', 'nexo'));?>', function( response ) {
								// Delete item from cart when confirmed
								if( response ) {
									v2Checkout.CartItems.splice( InCartIndex, 1 );
									v2Checkout.buildCartItemTable();
								}

							});
						}
					}
				}
			} else {
				if( parseFloat( _item[0].QUANTITE_RESTANTE ) - qte_to_add < 0 ) {
					NexoAPI.Notify().warning(
						'<?php echo addslashes(__('Stock épuisé', 'nexo'));?>',
						'<?php echo addslashes(__('Impossible d\'ajouter ce produit, car son stock est épuisé.', 'nexo'));?>'
					);
				} else {
					// improved @since 2.7.3
					// add meta by default
					var ItemMeta	=	NexoAPI.events.applyFilters( 'items_metas', [] );

					var FinalMeta	=	[ [ 'QTE_ADDED' ], [ qte_to_add ] ] ;

					_.each( ItemMeta, function( value, key ) {
						FinalMeta[0].push( _.keys( value )[0] );
						FinalMeta[1].push( _.values( value )[0] );
					});

					// @since 2.9.0
					// add unit item discount
					_item[0].DISCOUNT_TYPE		=	'percentage'; // has two type, "percent" and "flat";
					_item[0].DISCOUNT_AMOUNT	=	0;
					_item[0].DISCOUNT_PERCENT	=	0;

					v2Checkout.CartItems.unshift( _.extend( _item[0], _.object( FinalMeta[0], FinalMeta[1] ) ) );
				}
			}

			// Add Item To Cart
			NexoAPI.events.doAction( 'add_to_cart', v2Checkout );

			// Build Cart Table Items
			v2Checkout.refreshCart();
			v2Checkout.buildCartItemTable();

		} else {
			NexoAPI.Notify().error( '<?php echo addslashes(__('Impossible d\'ajouter l\'article', 'nexo'));?>', '<?php echo addslashes(__('Impossible de récupérer l\'article, ce dernier est introuvable, indisponible ou le code envoyé est incorrecte.', 'nexo'));?>' );
		}
	}
</script>
    <?php
}