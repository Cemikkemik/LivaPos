<?php
class NexoCouponController extends Tendoo_Module
{
    public function __construct()
    {
        parent::__construct();
    }

    /**
     *  index
     *  @param
     *  @return
    **/

    public function index( $page = 'list' )
    {
        $AnguCrud       =   new AngularCrudLibrary( 'nexo_coupons' );

        $AnguCrud->setColumns([
            'ID'                =>  __( 'Id', 'nexo' ),
            'CODE'              =>  __( 'Code', 'nexo' ),
            'AMOUNT'            =>  __( 'Valeur', 'nexo' ),
            'USAGE_LIMIT'       =>  __( 'Limite d\'utilisation', 'nexo' ),
            'MINIMUM_AMOUNT'    =>  __( 'Montant minimal', 'nexo' ),
            'MAXIMUM_AMOUNT'    =>  __( 'Montant maximal', 'nexo' ),
        ]);

        $AnguCrud->config([
            'baseUrl'           =>  site_url( array( 'dashboard', 'nexo_coupons', 'index' ) ),
            'page'              =>  $page,
            'crudTitle'         =>  __( 'Coupons', 'nexo' ),
            'primaryCol'        =>  'ID'
        ]);

        return $AnguCrud->LoadView();
    }
}
