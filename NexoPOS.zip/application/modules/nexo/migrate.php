<?php
return array(
	'2.9.1'	=>	dirname( __FILE__ ) . '/migrate/2.9.1.php',
	'2.9.0'	=>	dirname( __FILE__ ) . '/migrate/2.9.0.php',
	'2.8.2'	=>	dirname( __FILE__ ) . '/migrate/2.8.2.php',
	'2.8.1'	=>	dirname( __FILE__ ) . '/migrate/2.8.1.php',
	'2.8.0'	=>	dirname( __FILE__ ) . '/migrate/2.8.0.php',	
);
