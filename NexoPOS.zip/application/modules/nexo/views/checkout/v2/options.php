<div class="box collapse cart-options" id="collapseExample">
    <div class="box-header"><?php echo _e('Filtrer les catégories', 'nexo');?></div>
    <div class="box-body categories_dom_wrapper">
    </div>
    <div class="box-footer">
    	<button class="btn btn-primary close-item-options pull-right"><?php _e('Masquer les options', 'nexo');?></button>
    </div>
</div>