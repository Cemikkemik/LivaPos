<?php
    global $Options;
    $this->load->config( 'rest' );
    if (@$Options[ store_prefix() . 'disable_coupon' ] != 'yes' ):
?>

/**
 *  Check Coupon
 *  @param
 *  @return
**/

$scope.usedCoupon       =   [];

$scope.checkCoupon      =   function(){
    __windowSplash.showSplash();
    $http.get( '<?php echo site_url( array( 'rest', 'nexo', 'coupon' ) );?>' + '/' + $scope.couponCode, {
        headers			:	{
            '<?php echo $this->config->item('rest_key_name');?>'	:	'<?php echo @$Options[ 'rest_key' ];?>'
        }
    }).then(function( returned ) {
        __windowSplash.hideSplash();
        if( returned.data.length == 0 ) {
            NexoAPI.Notify().warning( '<?php echo _s( 'Attention', 'nexo' );?>', '<?php echo _s( 'Ce coupon n\'existe pas', 'nexo' );?>' );
        }
    },function(){
        __windowSplash.hideSplash();
    });
}

<?php
endif;
