<?php include_once( MODULESPATH . '/nexo/inc/angular/order-list/directives/loading-spinner.php' );?>
<?php include_once( MODULESPATH . '/nexo/inc/create-item-fields.php' );?>
<script type="text/javascript">
"use strict";
tendooApp.config(function($routeProvider) {
   $routeProvider
    .when("/clothes", {
        templateUrl : '<?php echo site_url( [ 'dashboard', 'nexo', 'produits', 'template', 'clothes' ] );?>'
    })
    .when("/tomato", {
        template : "<h1>Tomato</h1><p>Tomatoes contain around 95% water.</p>"
    })
    .otherwise({
        templateUrl : '<?php echo site_url( [ 'dashboard', 'nexo', 'produits', 'template', 'main' ] );?>'
    });
});

tendooApp.directive( 'itemVariation', function(){
    return {
        template :  <?php echo json_encode( $this->load->module_view( 'nexo', 'items/parts',[], true ) );?>
    }
});

tendooApp.directive( 'loader', function ($rootScope, $timeout) {
    return {
        // restrict: 'A',
        // replace: true,
        template: '<div class="nexo-overlay" style="width: 100%; height: 100%; background: rgba(255, 255, 255, 0.9); z-index: 5000; position: absolute; top: 0px; left: 0px;"><i class="fa fa-refresh fa-spin nexo-refresh-icon" style="color: rgb(0, 0, 0); font-size: 50px; position: absolute; top: 50%; left: 50%; margin-top: -25px; margin-left: -25px; width: 44px; height: 50px;"></i></div>',
        link: function (scope, elem, attrs) {
            var hideLoaderTimeout;
            var minLoaderDisplayTime = attrs.minLoaderDisplay || 200;
            scope.data = {
                startTime: undefined
            };

            var unregisterStart = $rootScope.$on('$routeChangeStart', function (event, toState, toParams, fromState) {
                scope.data.startTime = new Date();
                elem.removeClass('ng-hide');
            });

            var unregisterSuccess = $rootScope.$on('$routeChangeSuccess', function (event, toState, toParams, fromState) {
                var transitionTime = new Date() - scope.data.startTime;
                var loaderTimeout = minLoaderDisplayTime - transitionTime;
                loaderTimeout = loaderTimeout > 0 ? loaderTimeout : 0;
                hideLoaderTimeout = $timeout(function () {
                    elem.addClass('ng-hide');
                }, loaderTimeout);
            });

            var unregisterError = $rootScope.$on('$routeChangeError', function () {
                elem.addClass('ng-hide');
            });

            scope.$on('destroy', function () {
                unregisterStart();
                unregisterSuccess();
                unregisterError();
                $timeout.cancel(hideLoaderTimeout);
            });
        }
    };
});

tendooApp.controller( 'nexoItems', [ '$scope', '$http', '$location', function( $scope, $http, $location ){

    /**
     *  Add Variation
     *  @param
     *  @return
    **/

    $scope.addVariation         =   function(){
        if( $scope.itemVariations.length == 10 ) {
            NexoAPI.Notify().alert( '<?php echo _s( 'Attention', 'nexo' );?>', '<?php echo _s( 'Vous ne pouvez pas créer plus de 10 variations d\'un même produit.', 'nexo' );?>')
            return;
        }
        $scope.itemVariations.push({
            variationName        :   $scope.itemVariations[$scope.itemVariations.length - 1 ].variationName
        });
    }

    /**
     *  Get Icon using URL
     *  @param string icon
     *  @return string
    **/

    $scope.getIcon          =   function( string ){
        return '<?php echo module_url( 'nexo' ) . 'images/items/'; ?>' + string;
    }

    /**
     *  Remove Variation
     *  @param int variation index
     *  @return void
    **/

    $scope.removeVariation  =   function( $index ){
        $scope.itemVariations.splice( $index, 1 );
    }

    /**
     *  Select Type
     *  @param string item stype
     *  @return void
    **/

    $scope.selectType       =   function( type ){
        $location.url( type );
    }

    /**
     *  Show or Hide UI
     *  @param string ui namespace
     *  @return void
    **/

    $scope.show             =   function( namespace ) {
        if( namespace == 'selectType' ) {
            $scope.askProductType   =   true;
            $scope.showItemUI       =   false;
        } else if( namespace == 'showItemUI' ){
            $scope.askProductType   =   false;
            $scope.showItemUI       =   true;
        }
    }

    /**
     *  Toggle Tip
     *  @param object field
     *  @return boolean
    **/

    $scope.toggleFieldTip           =   function( field ) {
        if( angular.isUndefined( field.tip ) ) {
            field.tip   =   false;
        }
        return field.tip  = ! field.tip;
    }


    // Watch variation
    $scope.$watch( 'itemVariations', function(){
        if( $scope.itemVariations.length == 0 ) {
            $scope.itemVariations.push({
                variationName        :       $scope.itemName
            });
        }

        // Change Variation Name
        if( angular.isUndefined( $scope.itemVariations[0].variationName ) ) {
            $scope.itemVariations[0].variationName    =   '';
        }
    });

    // Items Types
    $scope.itemTypes        =   [{
        type    :   'clothes',
        icon    :   'shirt',
        text    :   '<?php echo __( 'Vêtements & Accessoires', 'nexo' );?>',
        desc    :   '<?php echo _s( 'Produits pour boutique de vêtement : vestes, chemises, pantalon, chaussures, lunettes & tous les acccéssoires de mode.', 'nexo' );?>'
    },{
        type    :   'medecine',
        icon    :   'medicine',
        text    :   '<?php echo __( 'Comprimé & Accessoires', 'nexo' );?>',
        desc    :   '<?php echo _s( 'Ce produit disposera des champs pour les produis des pharmacies.', 'nexo' );?>'
    },{
        type    :   'coupon',
        icon    :   'coupon',
        text    :   '<?php echo __( 'Coupon & Bon de commande', 'nexo' );?>',
        desc    :   '<?php echo _s( 'Ce produit sera liée à un bon de commande existant.', 'nexo' );?>'
    },{
        type    :   'beer',
        icon    :   'alcoholic',
        text    :   '<?php echo __( 'Bière & Liqueurs', 'nexo' );?>',
        desc    :   '<?php echo _s( 'Vous permettra de créer des produits pour un bar ou snack bar.', 'nexo' );?>'
    },{
        type    :   'food',
        icon    :   'turkey',
        text    :   '<?php echo __( 'Repas & Gateaux', 'nexo' );?>',
        desc    :   '<?php echo _s( 'Vous permettra de manger de produits comestibles.', 'nexo' );?>'
    },{
        type    :   'service',
        icon    :   'customer-service',
        text    :   '<?php echo __( 'Service', 'nexo' );?>',
        desc    :   '<?php echo _s( 'Vous pourrez créer un service vendable.', 'nexo' );?>'
    },{
        type    :   'digital',
        icon    :   'music-player',
        text    :   '<?php echo __( 'Digital', 'nexo' );?>',
        desc    :   '<?php echo _s( 'Vous pourrez créer produit digital.', 'nexo' );?>'
    }];

    // Tabs
    $scope.tabs             =   [{
        'namespace'     :  'basic',
        'title'         :  '<?php echo __( 'Informations de base', 'nexo' );?>',
    },{
        'namespace'     :  'shipping',
        'title'         :  '<?php echo __( 'Livraison', 'nexo' );?>',
    }];

    // Yes No Options
    $scope.YesNoOptions     =   [{
        value       :   'yes',
        label       :   '<?php echo _s( 'Oui', 'nexo' );?>'
    },{
        value       :   'no',
        label       :   '<?php echo _s( 'Non', 'nexo' );?>'
    }];

    // Variations
    $scope.itemVariations       =   new Array;

    // Fields
    $scope.fields           =   {
        basic           :   [{
            type        :   'text',
            label       :   '<?php echo _s( 'Nom de la variation', 'nexo' );?>',
            model       :   'variationName',
            show        :   function(){
                return $scope.itemVariations.length > 1
            },
            desc        :   '<?php echo _s( 'Veuillez choisir une désignation unique pour cette variation', 'nexo' );?>'
        },{
            type        :   'text',
            label       :   '<?php echo _s( 'Unité de Gestion de Stock', 'nexo' );?>',
            model       :   'variationSKU',
            show        :   function(){
                return true;
            },
            desc        :   '<?php echo _s( 'L\'unité de gestion de stock permet de distinguer les variations (ou les produits)', 'nexo' );?>'
        },{
            type        :   'select',
            label       :   '<?php echo _s( 'Type du Codebarre', 'nexo' );?>',
            model       :   'variationBarcodeType',
            show        :   function(){
                return true;
            },
            options         :   [{
                value       :   'ean8',
                label       :   'EAN 8'
            },{
                value       :   'ean13',
                label       :   'EAN 13'
            },{
                value       :   'codabar',
                label       :   'Codabar'
            },{
                value       :   'upc_a',
                label       :   'UPC A'
            },{
                value       :   'upc_e',
                label       :   'UPC E'
            },{
                value       :   'jan_13',
                label       :   'JAN-13'
            },{
                value       :   'isbn',
                label       :   'ISBN'
            },{
                value       :   'issn',
                label       :   'ISSN'
            },{
                value       :   'code_39',
                label       :   'CODE 39'
            },{
                value       :   'code_128',
                label       :   'Code 128'
            },{
                value       :   'msi_plessey',
                label       :   'MSI Plessey'
            },{
                value       :   'qr_code',
                label       :   'QR COde'
            },{
                value       :   'data_matrix',
                label       :   'Data Matrix'
            }],
            desc        :   '<?php echo _s( 'Vous pouvez utiliser le type du code barre déjà dans le produit.', 'nexo' );?>'
        },{
            type        :   'text',
            label       :   '<?php echo _s( 'Code Barre', 'nexo' );?>',
            model       :   'variationBarcode',
            show        :   function(){
                return true;
            },
            desc        :   '<?php echo _s( 'La valeur du codebarre peut être spécifiée dans ce champ.', 'nexo' );?>'
        }],
        shipping        :   [{
            type        :   'text',
            label       :   '<?php echo _s( 'Poids', 'nexo' );?>',
            show        :   function(){
                return true;
            },
            model       :   'variationWeight',
            desc        :   '<?php echo _s( 'Si le produit a un poid significatif, vous pouvez le mentionner.', 'nexo' );?>'
        },{
            type        :   'text',
            label       :   '<?php echo _s( 'Taille', 'nexo' );?>',
            show        :   function(){
                return true;
            },
            model       :   'variationHeight',
            desc        :   '<?php echo _s( 'Si le produit a une taille significative, vous pouvez la mentionner.', 'nexo' );?>'
        },{
            type        :   'text',
            label       :   '<?php echo _s( 'Largeur', 'nexo' );?>',
            show        :   function(){
                return true;
            },
            model       :   'variationWidth',
            desc        :   '<?php echo _s( 'Si le produit a une largeur significative, vous pouvez la mentionner.', 'nexo' );?>'
        },{
            type        :   'text',
            label       :   '<?php echo _s( 'Longueur', 'nexo' );?>',
            show        :   function(){
                return true;
            },
            model       :   'variationLength',
            desc        :   '<?php echo _s( 'Si le produit a une longueur significative, vous pouvez la mentionner.', 'nexo' );?>'
        }]
    }

    // Item Status
    $scope.itemStatus       =   $scope.YesNoOptions[0];

    $scope.docHeight        =   ( parseFloat( angular.element( '.content-wrapper' ).css( 'min-height' ) ) - 100 ) + 'px';
    $scope.askProductType   =   true;
    angular.element( '.content-wrapper .content-header' ).remove();
}]);
</script>
