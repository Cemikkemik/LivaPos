<div ng-controller="nexoItems" ng-cloak style="min-height: {{ docHeight }}">
    <ng-view></ng-view>
    <loader class="ng-hide"></loader>
</div>
