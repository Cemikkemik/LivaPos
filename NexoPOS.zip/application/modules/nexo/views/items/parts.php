<div class="nav-tabs-custom" ng-repeat="(index, variation) in itemVariations">
    <ul class="nav nav-tabs">
        <li ng-repeat="(k, tab) in tabs" class="{{ k == 0 ? 'active' : '' }}"><a href=".{{ tab.namespace + index }}" data-toggle="tab" aria-expanded="false">{{ tab.title }}</a></li>
        <li class="pull-right" ng-show="itemVariations.length > 1"><span title="<?php echo __( 'Ajouter une variation', 'nexo' );?>" class="btn btn-danger btn-md" ng-click="removeVariation( $index )"><i class="fa fa-remove"></i></span></li>
    </ul>
    <div class="tab-content">
      <div
        ng-repeat="(k,tab) in tabs"
        class="{{ k == 0 ? 'active' : '' }} tab-pane {{ tab.namespace + index  }} row">
        <div ng-repeat="field in fields[ tab.namespace ]" class="col-lg-6 col-sm-6 col-xs-12" ng-show="field.show( variation )">
            <div class="form-group" ng-if="field.type == 'text'">
                <div class="input-group">
                  <span class="input-group-addon">{{ field.label }}</span>
                  <input type="text" class="form-control" ng-model="variation[ field.model ]" placeholder="{{ field.placeholder }}">
                </div>
                <p class="help-block" style="height:30px;font-size:12px;">{{ field.desc }}</p>
            </div>
            <div class="form-group" ng-if="field.type == 'select'">
                <div class="input-group">
                    <span class="input-group-addon">{{ field.label }}</span>
                    <select class="form-control" ng-model="variation[ field.model ]">
                        <option ng-repeat="option in field.options" value="{{ option.value }}">{{ option.label }}</option>
                    </select>
                </div>
                <p class="help-block" style="height:30px;font-size:12px;">{{ field.desc }}</p>
            </div>
        </div>
      </div>
    </div>
    <!-- /.tab-content -->
</div>
