<div class="row">
    <div class="col-md-12">
        <h3 style="margin-top:0px;"><?php echo __( 'Créer un nouveau produit', 'nexo' );?></h3>
    </div>
    <div class="col-md-9">
        <input placeholder="<?php echo __( 'Nom du produit', 'nexo' );?>" type="text" class="form-control input-lg" style="line-height:40px;font-size:25px;" name="itemName" ng-model="itemName" value="">
        <br>
        <item-variation></item-variation>
    </div>
    <div class="col-md-3">
        <div class="box">
            <div class="box-header">
                <span><?php echo __( 'Publier', 'nexo' );?></span>
            </div>
            <div class="box-body">
                <div class="input-group">
                  <span class="input-group-addon"><?php echo __( 'Catégorie', 'nexo' );?></span>
                  <select ng-model="itemStatus" class="form-control" placeholder="" ng-options="option as option.label for option in YesNoOptions track by option.value">
                  </select>
                  <span class="input-group-btn">
                    <button class="btn btn-default" type="button"><i class="fa fa-plus"></i></button>
                  </span>
                </div>
                <span><?php _e( 'Permet d\'assigner une catégorie à un produit', 'nexo' );?></span>
                <br><br>
                <div class="input-group">
                  <span class="input-group-addon"><?php echo __( 'Fabriquant', 'nexo' );?></span>
                  <select ng-model="itemStatus" class="form-control" placeholder="" ng-options="option as option.label for option in YesNoOptions track by option.value">
                  </select>
                  <span class="input-group-btn">
                    <button class="btn btn-default" type="button"><i class="fa fa-plus"></i></button>
                  </span>
                </div>
                <span><?php _e( 'Permet d\'assigner un fabriquant à ce produit.', 'nexo' );?></span>
                <br><br>
                <div class="input-group">
                  <span class="input-group-addon"><?php echo __( 'Unité', 'nexo' );?></span>
                  <select ng-model="itemStatus" class="form-control" placeholder="" ng-options="option as option.label for option in YesNoOptions track by option.value">
                  </select>
                  <span class="input-group-btn">
                    <button class="btn btn-default" type="button"><i class="fa fa-plus"></i></button>
                  </span>
                </div>
                <span><?php _e( 'Permet d\'assigner une unité de mesure à ce produit.', 'nexo' );?></span>
                <br><br>
                <div class="input-group">
                  <span class="input-group-addon"><?php echo __( 'Collection', 'nexo' );?></span>
                  <select ng-model="itemStatus" class="form-control" placeholder="" ng-options="option as option.label for option in YesNoOptions track by option.value">
                  </select>
                  <span class="input-group-btn">
                    <button class="btn btn-default" type="button"><i class="fa fa-plus"></i></button>
                  </span>
                </div>
                <span><?php _e( 'Sélectionnez la collection à partir de laquelle le produit entre en stock.', 'nexo' );?></span>
                <br><br>
                <div class="input-group">
                  <span class="input-group-addon"><?php echo __( 'Statut', 'nexo' );?></span>
                  <select ng-model="itemStatus" class="form-control" placeholder="" ng-options="option as option.label for option in YesNoOptions track by option.value">
                  </select>
                </div>
                <span><?php _e( 'Permet de déterminer si oui ou non un produit est disponible pour la vente', 'nexo' );?></span>
                <br><br>
                <input type="button" class="btn btn-info" value="<?php echo __( 'Ajouter une variation', 'nexo' );?>" ng-click="addVariation()"/><br>
                <span><?php echo __( 'Vous permet d\'ajouter plusieurs variations', 'nexo' );?></span>
            </div>
            <div class="box-footer">
                <input type="button" class="btn btn-primary" value="<?php echo __( 'Enregistrer', 'nexo' );?>">
            </div>
        </div>
    </div>
</div>
