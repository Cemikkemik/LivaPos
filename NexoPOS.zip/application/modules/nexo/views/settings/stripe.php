<?php
// Deprecated

$this->Gui->output();
