<?php

$this->Gui->output();