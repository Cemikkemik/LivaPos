<?php
$lang[ 'not-allowed-to-access-to-that-store' ]  =   tendoo_error( __( 'You\'re not allowed to access to that store', 'nsam' ) );
