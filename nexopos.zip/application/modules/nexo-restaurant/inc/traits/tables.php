<?php
defined('BASEPATH') OR exit('No direct script access allowed');

use Curl\Curl;

trait nexo_restaurant_tables
{
    /**
     *  get Rooms
     *  @param string int
     *  @return json
    **/

    public function tables_get( $id = null )
    {
        if( $id != null ) {
            $this->db->where( 'ID', $id );
        }

        $this->response(
            $this->db->get( store_prefix() . 'nexo_restaurant_tables' )
            ->result(),
            200
        );
    }

    /**
     *  Get Area from Rooms
     *  @param int room id
     *  @return json
    **/

    public function tables_from_area_get( $areaID )
    {
        $this->db->select(
            store_prefix() . 'nexo_restaurant_tables.NAME as TABLE_NAME,' .
            store_prefix() . 'nexo_restaurant_tables.STATUS as STATUS,' .
            store_prefix() . 'nexo_restaurant_tables.MAX_SEATS as MAX_SEATS,' .
            store_prefix() . 'nexo_restaurant_tables.CURRENT_SEATS_USED as CURRENT_SEATS_USED,' .
            store_prefix() . 'nexo_restaurant_tables.ID as TABLE_ID,' .
            store_prefix() . 'nexo_restaurant_areas.ID as AREA_ID,' .
            store_prefix() . 'nexo_restaurant_tables.SINCE as SINCE'
        )->from( store_prefix() . 'nexo_restaurant_tables' )
        ->join( store_prefix() . 'nexo_restaurant_areas', store_prefix() . 'nexo_restaurant_tables.REF_AREA = ' . store_prefix() . 'nexo_restaurant_areas.ID' )
        ->where( store_prefix() . 'nexo_restaurant_areas.ID', $areaID );

        $query  =   $this->db->get();

        $this->response( $query->result(), 200 );
    }

    /**
     *  Edit Table
     *  @param
     *  @return
    **/

    public function table_usage_put( $table_id )
    {
        $order      =   $this->db->where( 'ID', $this->put( 'ORDER_ID' ) )
        ->get( store_prefix() . 'nexo_commandes' )->result_array();

        $data       =   [
            'CURRENT_SEATS_USED'    =>  $this->put( 'CURRENT_SEATS_USED' ),
            'STATUS'                =>  $this->put( 'STATUS' )
        ];

        if( $this->put( 'STATUS' ) == 'in_use' ) {
            // add table relation to order
            $this->db->insert( store_prefix() . 'nexo_restaurant_tables_relation_orders', [
                'REF_ORDER'     =>  $this->put( 'ORDER_ID' ),
                'REF_TABLE'     =>  $table_id
            ]);
        } else {
            // update this only when the table is not in use
            if( ! empty( @$order[0][ 'DATE_CREATION' ] ) ) {
                $data[ 'SINCE' ]        =   @$order[0][ 'DATE_CREATION' ];
            } else {
                $data[ 'SINCE' ]        =   '0000-00-00 00:00:00';
            }
        }        

        

        $this->db->where( 'ID', $table_id )->update( store_prefix() . 'nexo_restaurant_tables', $data );
        return $this->__success();
    }

    /**
     * Dettache order to table
     * @param order id
     * @param table
     * @return void
    **/

    public function dettach_order_to_table( $order_id, $table_id ) 
    {
        $this->db->where( 'REF_ORDER', $order_id )
        ->where( 'TABLE_ID', $table_id )
        ->delete();
        $this->__success();
    }

    /**
     * Pay an order
     * @param int order id
     * @return json
    **/

    public function pay_order_put( $order_id )
    {
        $current_order          =    $this->db->where('ID', $order_id)
        ->get( store_prefix() . 'nexo_commandes')
        ->result_array();

        $this->db->where( 'ID', $order_id )
        ->update( store_prefix() . 'nexo_commandes', [
            'TYPE'      =>  $this->put( 'TYPE' )
        ]);

        // @since 2.9 
        // @package nexopos
		// Save order payment
		$this->load->config( 'rest' );
		$Curl			=	new Curl;
        // $header_key		=	$this->config->item( 'rest_key_name' );
		// $header_value	=	$_SERVER[ 'HTTP_' . $this->config->item( 'rest_key_name' ) ];
		$Curl->setHeader($this->config->item('rest_key_name'), $_SERVER[ 'HTTP_' . $this->config->item('rest_header_key') ]);

        if( is_array( $this->put( 'payments' ) ) ) {
			foreach( $this->put( 'payments' ) as $payment ) {

				$Curl->post( site_url( array( 'rest', 'nexo', 'order_payment', store_get_param( '?' ) ) ), array(
					'author'		=>	User::id(),
					'date'			=>	date_now(),
					'payment_type'	=>	$payment[ 'namespace' ],
					'amount'		=>	$payment[ 'amount' ],
					'order_code'	=>	$current_order[0][ 'CODE' ]
				) );

                // @since 3.1
                // if the payment is a coupon, then we'll increase his usage
                if( $payment[ 'namespace' ] == 'coupon' ) {
                    
                    $coupon         =   $this->db->where( 'ID', $payment[ 'meta' ][ 'coupon_id' ] )
                    ->get( store_prefix() . 'nexo_coupons' )
                    ->result_array();

                    $this->db->where( 'ID', $payment[ 'meta' ][ 'coupon_id' ] )
                    ->update( store_prefix() . 'nexo_coupons', [
                        'USAGE_COUNT'   =>  intval( $coupon[0][ 'USAGE_COUNT' ] ) + 1
                    ]);
                }
			}
        }
        
        $this->response(array(
            'order_id'          =>    $order_id,
            'order_type'        =>    $this->put( 'TYPE' ),
            'order_code'        =>    $current_order[0][ 'CODE' ]
        ), 200);
    }

}
