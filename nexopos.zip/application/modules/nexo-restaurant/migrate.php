<?php
return array(
	'1.4.1' 		=>	dirname( __FILE__ ) . '/migrate/1.4.1.php',
	'1.4.0' 		=>	dirname( __FILE__ ) . '/migrate/1.4.0.php',
	'1.3.0'		=>	dirname( __FILE__ ) . '/migrate/1.3.0.php',
	'1.2.3'		=>	dirname( __FILE__ ) . '/migrate/1.2.3.php',
);
