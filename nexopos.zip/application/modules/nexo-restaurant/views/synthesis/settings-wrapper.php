<script type="text/javascript">
<?php include_once( dirname( __FILE__ ) . '/script.js' );?>;
</script>