<script>
tendooApp.directive( 'readyOrders', function(){
	return {
		templateUrl         :    '<?php echo site_url([ 'dashboard', store_slug(), 'nexo-restaurant', 'templates', 'ready-orders' ] );?>',
		restrict            :   'E'
	}
});

tendooApp.controller( 'readerOrdersCTRL', [ 
'$scope', '$timeout', '$compile', '$rootScope', '$interval', '$http', '$filter', 
function( $scope, $timeout, $compile, $rootScope, $interval, $http, $filter ){
	$scope.$watch( 'newOrders', function( previous, current ){
		console.log( previous, current );
		if( $scope.newOrders > 0 && previous < current ){
			NexoAPI.Toast()( '<?php echo _s( 'A new order is ready', 'nexo-restaurant' );?>' );
		}
	});

	// $( '.new-orders-button' ).append( '<span class="badge badge-warning">42</span>' );
	$scope.newOrders         	=    0;  

	$scope.selectedOrder 		=	null;
	
	/**
	* Open Waiter Screen
	* @return void
	**/
	
	$scope.openReadyOrders       =    function(){
		NexoAPI.Bootbox().alert({
			message 		:	'<div class="ready-orders"><ready-orders></ready-orders></div>',
			title          :	'<?php echo _s( 'Ready orders', 'nexo' );?>',
			buttons 		:	{
				ok: {
					label: '<span ><?php echo _s( 'Close', 'nexo-restaurant' );?></span></span>',
					className: 'btn-default'
				},
			}, 
			callback 		:	function( action ) {
				// closing
			},
			className 	:	'ready-orders-box'
		});
		
		$scope.windowHeight           =	window.innerHeight;
		$scope.wrapperHeight          =	$scope.windowHeight - ( ( 56 * 2 ) + 30 );
		
		$timeout( function(){
			angular.element( '.ready-orders-box .modal-dialog' ).css( 'width', '60%' );
			angular.element( '.ready-orders-box .modal-body' ).css( 'padding-top', '0px' );
			angular.element( '.ready-orders-box .modal-body' ).css( 'padding-bottom', '0px' );
			angular.element( '.ready-orders-box .modal-body' ).css( 'padding-left', '0px' );
			angular.element( '.ready-orders-box .modal-body' ).css( 'padding-right', '0px' );
			angular.element( '.ready-orders-box .modal-body' ).css( 'height', $scope.wrapperHeight );
			angular.element( '.ready-orders-box .modal-body' ).css( 'overflow-x', 'hidden' );
		}, 150 );
		
		$( '.ready-orders-box' ).last().find( '.modal-footer' ).prepend( '<button ng-show="selectedOrder != null" ng-click="runPayment()" class="btn btn-primary"><?php echo _s( 'Pay that order', 'nexo-restarant' );?></button>' );
		
		$( '.ready-orders' ).html( 
			$compile( $( '.ready-orders').html() )( $scope ) 
		);
		$( '.ready-orders-box' )
		.find( '.modal-footer' )
		.html( $compile( $( '.ready-orders-box' ).find( '.modal-footer' ).html() )( $scope ) );
	}
	
	/**
	* Payement
	* @return void
	**/
	
	$scope.runPayment             =    function(){
		

		v2Checkout.emptyCartItemTable();
		v2Checkout.CartItems 			=	$scope.selectedOrder.items;

		// _.each( v2Checkout.CartItems, function( value, key ) {
		// 	value.QTE_ADDED		=	value.QUANTITE;
		// });

		// // @added CartRemisePercent
		// // @since 2.9.6

		if( $scope.selectedOrder.REMISE_TYPE != '' ) {
			v2Checkout.CartRemiseType			=	$scope.selectedOrder.REMISE_TYPE;
			v2Checkout.CartRemise				=	NexoAPI.ParseFloat( $scope.selectedOrder.REMISE );
			v2Checkout.CartRemisePercent			=	NexoAPI.ParseFloat( $scope.selectedOrder.REMISE_PERCENT );
			v2Checkout.CartRemiseEnabled			=	true;
		}

		if( parseFloat( $scope.selectedOrder.GROUP_DISCOUNT ) > 0 ) {
			v2Checkout.CartGroupDiscount 			=	parseFloat( $scope.selectedOrder.GROUP_DISCOUNT ); // final amount
			v2Checkout.CartGroupDiscountAmount 	=	parseFloat( $scope.selectedOrder.GROUP_DISCOUNT ); // Amount set on each group
			v2Checkout.CartGroupDiscountType 		=	'amount'; // Discount type
			v2Checkout.CartGroupDiscountEnabled 	=	true;
		}

		v2Checkout.CartCustomerID 			=	$scope.selectedOrder.REF_CLIENT;
		// @since 2.7.3
		v2Checkout.CartNote 				=	$scope.selectedOrder.DESCRIPTION;
		v2Checkout.CartTitle 				=	$scope.selectedOrder.TITRE;

		// @since 3.1.2
		v2Checkout.CartShipping 				=	parseFloat( $scope.selectedOrder.SHIPPING_AMOUNT );
		$scope.price 						=	v2Checkout.CartShipping; // for shipping directive
		$( '.cart-shipping-amount' ).html( $filter( 'moneyFormat' )( $scope.price ) );

		// Restore Custom Ristourne
		v2Checkout.restoreCustomRistourne();

		// Refresh Cart
		// Reset Cart state
		v2Checkout.buildCartItemTable();
		v2Checkout.refreshCart();
		v2Checkout.refreshCartValues();
		v2Checkout.ProcessURL				=	"<?php echo site_url(array( 'rest', 'nexo-restaurant', 'pay_order' ));?>" + '/' + $scope.selectedOrder.ID + "?store_id=<?php echo get_store_id();?>";
		v2Checkout.ProcessType				=	'PUT';
		// convert type to terminated
		if( _.indexOf( [ 'dinein', 'takeaway', 'delivery', 'booking' ], $scope.selectedOrder.REAL_TYPE ) != -1 ) {
			v2Checkout.CartType 				=	'nexo_order_' + $scope.selectedOrder.REAL_TYPE + '_paid';
		} else {
			// $scope.openReadyOrders();
			v2Checkout.resetCart();
			v2Checkout.ProcessURL 		=	"<?php echo site_url(array( 'rest', 'nexo', 'order', User::id() ));?>?store_id=<?php echo get_store_id();?>";
			v2Checkout.ProcessType 		=	'POST';
			return NexoAPI.Toast()( '<?php echo _s( 'The order type is not supported.', 'nexo-restaurant' );?>' );
		}

		// // Restore Shipping
		// // @since 3.1
		// _.each( $scope.selectedOrder.shipping, ( value, key ) => {
		// 	$scope[ key ] 	=	value;
		// });

		$rootScope.$emit( 'payBox.openPayBox' );
	}
	
	/***
	* Select Order
	* @return void
	**/
	
	$scope.selectOrder            =    function( order ) {
		// unselect all orders
		_.each( $scope.orders, function( _order ) {
			_order.active       =    false;
		});
		
		order.active             =    true;
		$scope.selectedOrder 	=	order;
	}

	/**
	 * Resume Orders
	 * @return string
	**/

	$scope.resumeItems 		=	function( items ) {
		let itemNames 		=	[];
		_.each( items, function( item ){
			itemNames.push( item.DESIGN );
		});
		return itemNames.toString();
	}

	/**
	 * Time SPan
	 * @param object order
	 * @return string
	**/

	$scope.timeSpan 		=	function( order ){
		return moment( order.DATE_CREATION ).from( tendoo.date.format() );
	}

	$scope.rawOrders 			=	[];
	$scope.rawOrdersCodes 		=	[];
	$scope.orders 				=	[];
	$scope.ordersCodes  		=	[];
	
	$interval( function(){
		$http.get( '<?php echo site_url([ 'dashboard', store_slug(), 'nexo-restaurant', 'get_orders' ]);?>?from-room=' + $scope.room_id + '&takeaway_kitchen=<?php echo store_option( 'takeaway_kitchen' );?>&current_kitchen=' + $scope.kitchen_id )
		.then( function( returned ){
			$scope.rawOrders		=	[];
			$scope.rawOrdersCodes 	=	[];
			
			_.each( returned.data, function( order ) {
				if( order.TYPE.substr(-5) == 'ready' ) {
					$scope.rawOrders.unshift( order );
					$scope.rawOrdersCodes.unshift( order.CODE );
				}
			});

			_.each( $scope.rawOrdersCodes, function( rawCode, index ){
				if( _.indexOf( $scope.ordersCodes, rawCode ) == -1 ) {
					$scope.orders.unshift( $scope.rawOrders[ index ] );
					$scope.ordersCodes.unshift( rawCode );
					$scope.newOrders++;
				}
			});
		});
	}, 5000 );

	NexoAPI.events.addAction( 'close_paybox', function(){
		// if current order is a modification
		// we can cancel that.
		if( v2Checkout.ProcessType == 'PUT' ) {
			$scope.openReadyOrders();
			v2Checkout.resetCart();
			v2Checkout.ProcessURL 		=	"<?php echo site_url(array( 'rest', 'nexo', 'order', User::id() ));?>?store_id=<?php echo get_store_id();?>";
			v2Checkout.ProcessType 		=	'POST';
		}
	});

	/**
	 *  Test order type to remove paid order from the list
	**/

	NexoAPI.events.addFilter( 'test_order_type', function( data ){
		if( data[1].order_type.substr( -4 ) == 'paid' ) {
			let indexToRemove 			=	[];
			_.each( $scope.orders, function( order, index ){
				// if that order has been found on the ready order list
				console.log( order, data );
				if( order.CODE == data[1].order_code ) {
					indexToRemove.push( index );
					_.each( $scope.ordersCodes, function( orderCode, __index ) {
						if( orderCode == data[1].order_code ) {
							$scope.ordersCodes.splice( __index, 1 );
						}
					});
					// reduce notice
					$scope.newOrders--; // it's not supposed to be lower than 0
				}
			});

			_.each( indexToRemove, function( index ) {
				$scope.orders.splice( index, 1 );
			});
		}
		return data;
	});

	/**
	 * Watch Events
	**/

	$scope.$on( 'open-ready-orders', function(){
		$scope.openReadyOrders();
	});
}]);
</script>