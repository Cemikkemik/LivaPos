<div style="min-height: {{ docHeight }}">
    <ng-view></ng-view>
</div>
