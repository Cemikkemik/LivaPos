<div class="row">
    <div class="col-md-12">
        <h3 style="margin-top:0px;"><?php echo __ ( 'Créer une collection', 'nexo' );?><span ng-click="back()" class="btn btn-primary btn-sm pull-right"><?php echo __( 'Annuler', 'nexo' );?></span></h3>
    </div>
</div>
