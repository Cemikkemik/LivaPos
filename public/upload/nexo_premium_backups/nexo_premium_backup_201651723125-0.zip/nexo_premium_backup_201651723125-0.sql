#
# TABLE STRUCTURE FOR: tendoo_nexo_arrivages
#

DROP TABLE IF EXISTS `tendoo_nexo_arrivages`;

CREATE TABLE `tendoo_nexo_arrivages` (
  `ID` int(50) NOT NULL AUTO_INCREMENT,
  `TITRE` varchar(200) NOT NULL,
  `DESCRIPTION` text NOT NULL,
  `DATE_CREATION` datetime NOT NULL,
  `DATE_MOD` datetime NOT NULL,
  `AUTHOR` int(50) NOT NULL,
  `FOURNISSEUR_REF_ID` int(50) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `tendoo_nexo_arrivages` (`ID`, `TITRE`, `DESCRIPTION`, `DATE_CREATION`, `DATE_MOD`, `AUTHOR`, `FOURNISSEUR_REF_ID`) VALUES ('1', 'Collection 1', 'Special collection for winter clothing', '2016-05-08 05:07:34', '0000-00-00 00:00:00', '2', '1');
INSERT INTO `tendoo_nexo_arrivages` (`ID`, `TITRE`, `DESCRIPTION`, `DATE_CREATION`, `DATE_MOD`, `AUTHOR`, `FOURNISSEUR_REF_ID`) VALUES ('2', 'Collection 2', 'Special collection for summer clothes', '2016-05-08 05:07:34', '0000-00-00 00:00:00', '2', '2');


#
# TABLE STRUCTURE FOR: tendoo_nexo_articles
#

DROP TABLE IF EXISTS `tendoo_nexo_articles`;

CREATE TABLE `tendoo_nexo_articles` (
  `ID` int(50) NOT NULL AUTO_INCREMENT,
  `DESIGN` varchar(200) NOT NULL,
  `REF_RAYON` int(11) NOT NULL,
  `REF_SHIPPING` int(11) NOT NULL,
  `REF_CATEGORIE` int(11) NOT NULL,
  `QUANTITY` int(11) NOT NULL,
  `SKU` varchar(220) NOT NULL,
  `QUANTITE_RESTANTE` int(11) NOT NULL,
  `QUANTITE_VENDU` int(11) NOT NULL,
  `DEFECTUEUX` int(11) NOT NULL,
  `PRIX_DACHAT` int(11) NOT NULL,
  `FRAIS_ACCESSOIRE` int(11) NOT NULL,
  `COUT_DACHAT` int(11) NOT NULL,
  `TAUX_DE_MARGE` double NOT NULL,
  `PRIX_DE_VENTE` int(11) NOT NULL,
  `TAILLE` varchar(200) NOT NULL,
  `POIDS` varchar(200) NOT NULL,
  `COULEUR` varchar(200) NOT NULL,
  `HAUTEUR` varchar(200) NOT NULL,
  `LARGEUR` varchar(200) NOT NULL,
  `PRIX_PROMOTIONEL` int(11) NOT NULL,
  `SPECIAL_PRICE_START_DATE` datetime NOT NULL,
  `SPECIAL_PRICE_END_DATE` datetime NOT NULL,
  `DESCRIPTION` text NOT NULL,
  `APERCU` varchar(200) NOT NULL,
  `CODEBAR` varchar(200) NOT NULL,
  `DATE_CREATION` datetime NOT NULL,
  `DATE_MOD` datetime NOT NULL,
  `AUTHOR` int(50) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

INSERT INTO `tendoo_nexo_articles` (`ID`, `DESIGN`, `REF_RAYON`, `REF_SHIPPING`, `REF_CATEGORIE`, `QUANTITY`, `SKU`, `QUANTITE_RESTANTE`, `QUANTITE_VENDU`, `DEFECTUEUX`, `PRIX_DACHAT`, `FRAIS_ACCESSOIRE`, `COUT_DACHAT`, `TAUX_DE_MARGE`, `PRIX_DE_VENTE`, `TAILLE`, `POIDS`, `COULEUR`, `HAUTEUR`, `LARGEUR`, `PRIX_PROMOTIONEL`, `SPECIAL_PRICE_START_DATE`, `SPECIAL_PRICE_END_DATE`, `DESCRIPTION`, `APERCU`, `CODEBAR`, `DATE_CREATION`, `DATE_MOD`, `AUTHOR`) VALUES ('1', 'Article 1', '1', '1', '1', '5000', 'UGS1', '4991', '9', '0', '65', '5', '70', '46.153846153846', '100', '38', '300', 'Red', '25', '8', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '../modules/nexo/images/produit-1.jpg', '147852', '2016-05-08 05:07:35', '2016-05-08 05:47:59', '2');
INSERT INTO `tendoo_nexo_articles` (`ID`, `DESIGN`, `REF_RAYON`, `REF_SHIPPING`, `REF_CATEGORIE`, `QUANTITY`, `SKU`, `QUANTITE_RESTANTE`, `QUANTITE_VENDU`, `DEFECTUEUX`, `PRIX_DACHAT`, `FRAIS_ACCESSOIRE`, `COUT_DACHAT`, `TAUX_DE_MARGE`, `PRIX_DE_VENTE`, `TAILLE`, `POIDS`, `COULEUR`, `HAUTEUR`, `LARGEUR`, `PRIX_PROMOTIONEL`, `SPECIAL_PRICE_START_DATE`, `SPECIAL_PRICE_END_DATE`, `DESCRIPTION`, `APERCU`, `CODEBAR`, `DATE_CREATION`, `DATE_MOD`, `AUTHOR`) VALUES ('2', 'Article 2', '4', '1', '4', '6000', 'UGS2', '5993', '7', '0', '10', '3', '13', '20', '15', '', '10', 'Yellow', '3', '1', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '../modules/nexo/images/produit-2.jpg', '258741', '2016-05-08 05:07:35', '2016-05-08 05:48:16', '2');
INSERT INTO `tendoo_nexo_articles` (`ID`, `DESIGN`, `REF_RAYON`, `REF_SHIPPING`, `REF_CATEGORIE`, `QUANTITY`, `SKU`, `QUANTITE_RESTANTE`, `QUANTITE_VENDU`, `DEFECTUEUX`, `PRIX_DACHAT`, `FRAIS_ACCESSOIRE`, `COUT_DACHAT`, `TAUX_DE_MARGE`, `PRIX_DE_VENTE`, `TAILLE`, `POIDS`, `COULEUR`, `HAUTEUR`, `LARGEUR`, `PRIX_PROMOTIONEL`, `SPECIAL_PRICE_START_DATE`, `SPECIAL_PRICE_END_DATE`, `DESCRIPTION`, `APERCU`, `CODEBAR`, `DATE_CREATION`, `DATE_MOD`, `AUTHOR`) VALUES ('3', 'Article 3', '3', '1', '3', '7000', 'UGS3', '6985', '14', '1', '100', '20', '120', '30', '150', '', '10', 'Blue', '3', '1', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '../modules/nexo/images/produit-3.jpg', '258963', '2016-05-08 05:07:36', '2016-05-08 05:48:30', '2');
INSERT INTO `tendoo_nexo_articles` (`ID`, `DESIGN`, `REF_RAYON`, `REF_SHIPPING`, `REF_CATEGORIE`, `QUANTITY`, `SKU`, `QUANTITE_RESTANTE`, `QUANTITE_VENDU`, `DEFECTUEUX`, `PRIX_DACHAT`, `FRAIS_ACCESSOIRE`, `COUT_DACHAT`, `TAUX_DE_MARGE`, `PRIX_DE_VENTE`, `TAILLE`, `POIDS`, `COULEUR`, `HAUTEUR`, `LARGEUR`, `PRIX_PROMOTIONEL`, `SPECIAL_PRICE_START_DATE`, `SPECIAL_PRICE_END_DATE`, `DESCRIPTION`, `APERCU`, `CODEBAR`, `DATE_CREATION`, `DATE_MOD`, `AUTHOR`) VALUES ('4', 'Article 4', '2', '1', '2', '800', 'UGS4', '799', '1', '0', '120', '20', '140', '41.666666666667', '190', '', '10', 'Pink', '3', '1', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '../modules/nexo/images/produit-4.jpg', '369852', '2016-05-08 05:07:36', '2016-05-08 05:48:45', '2');
INSERT INTO `tendoo_nexo_articles` (`ID`, `DESIGN`, `REF_RAYON`, `REF_SHIPPING`, `REF_CATEGORIE`, `QUANTITY`, `SKU`, `QUANTITE_RESTANTE`, `QUANTITE_VENDU`, `DEFECTUEUX`, `PRIX_DACHAT`, `FRAIS_ACCESSOIRE`, `COUT_DACHAT`, `TAUX_DE_MARGE`, `PRIX_DE_VENTE`, `TAILLE`, `POIDS`, `COULEUR`, `HAUTEUR`, `LARGEUR`, `PRIX_PROMOTIONEL`, `SPECIAL_PRICE_START_DATE`, `SPECIAL_PRICE_END_DATE`, `DESCRIPTION`, `APERCU`, `CODEBAR`, `DATE_CREATION`, `DATE_MOD`, `AUTHOR`) VALUES ('5', 'Article 5', '2', '1', '2', '400', 'UGS5', '400', '0', '0', '120', '20', '140', '41.666666666667', '190', '', '10', 'Black', '3', '1', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '../modules/nexo/images/produit-5.jpg', '987456', '2016-05-08 05:07:36', '2016-05-08 05:49:02', '2');
INSERT INTO `tendoo_nexo_articles` (`ID`, `DESIGN`, `REF_RAYON`, `REF_SHIPPING`, `REF_CATEGORIE`, `QUANTITY`, `SKU`, `QUANTITE_RESTANTE`, `QUANTITE_VENDU`, `DEFECTUEUX`, `PRIX_DACHAT`, `FRAIS_ACCESSOIRE`, `COUT_DACHAT`, `TAUX_DE_MARGE`, `PRIX_DE_VENTE`, `TAILLE`, `POIDS`, `COULEUR`, `HAUTEUR`, `LARGEUR`, `PRIX_PROMOTIONEL`, `SPECIAL_PRICE_START_DATE`, `SPECIAL_PRICE_END_DATE`, `DESCRIPTION`, `APERCU`, `CODEBAR`, `DATE_CREATION`, `DATE_MOD`, `AUTHOR`) VALUES ('6', 'Article 6', '2', '1', '2', '15', 'UGS6', '15', '0', '0', '80', '20', '100', '25', '120', '', '8', 'Black', '3', '1', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '../modules/nexo/images/produit-6.jpg', '781124', '2016-05-08 05:07:36', '0000-00-00 00:00:00', '2');
INSERT INTO `tendoo_nexo_articles` (`ID`, `DESIGN`, `REF_RAYON`, `REF_SHIPPING`, `REF_CATEGORIE`, `QUANTITY`, `SKU`, `QUANTITE_RESTANTE`, `QUANTITE_VENDU`, `DEFECTUEUX`, `PRIX_DACHAT`, `FRAIS_ACCESSOIRE`, `COUT_DACHAT`, `TAUX_DE_MARGE`, `PRIX_DE_VENTE`, `TAILLE`, `POIDS`, `COULEUR`, `HAUTEUR`, `LARGEUR`, `PRIX_PROMOTIONEL`, `SPECIAL_PRICE_START_DATE`, `SPECIAL_PRICE_END_DATE`, `DESCRIPTION`, `APERCU`, `CODEBAR`, `DATE_CREATION`, `DATE_MOD`, `AUTHOR`) VALUES ('7', 'Article 7', '2', '1', '2', '15', 'UGS7', '13', '2', '0', '80', '20', '100', '25', '120', '', '8', 'Cyan', '3', '1', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '../modules/nexo/images/produit-7.jpg', '789654', '2016-05-08 05:07:36', '0000-00-00 00:00:00', '2');
INSERT INTO `tendoo_nexo_articles` (`ID`, `DESIGN`, `REF_RAYON`, `REF_SHIPPING`, `REF_CATEGORIE`, `QUANTITY`, `SKU`, `QUANTITE_RESTANTE`, `QUANTITE_VENDU`, `DEFECTUEUX`, `PRIX_DACHAT`, `FRAIS_ACCESSOIRE`, `COUT_DACHAT`, `TAUX_DE_MARGE`, `PRIX_DE_VENTE`, `TAILLE`, `POIDS`, `COULEUR`, `HAUTEUR`, `LARGEUR`, `PRIX_PROMOTIONEL`, `SPECIAL_PRICE_START_DATE`, `SPECIAL_PRICE_END_DATE`, `DESCRIPTION`, `APERCU`, `CODEBAR`, `DATE_CREATION`, `DATE_MOD`, `AUTHOR`) VALUES ('8', 'Article 8', '2', '1', '2', '15', 'UGS7', '15', '0', '0', '120', '15', '135', '133.33333333333', '300', '', '8', 'Yellow', '3', '1', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '../modules/nexo/images/produit-8.jpg', '456987', '2016-05-08 05:07:36', '0000-00-00 00:00:00', '2');
INSERT INTO `tendoo_nexo_articles` (`ID`, `DESIGN`, `REF_RAYON`, `REF_SHIPPING`, `REF_CATEGORIE`, `QUANTITY`, `SKU`, `QUANTITE_RESTANTE`, `QUANTITE_VENDU`, `DEFECTUEUX`, `PRIX_DACHAT`, `FRAIS_ACCESSOIRE`, `COUT_DACHAT`, `TAUX_DE_MARGE`, `PRIX_DE_VENTE`, `TAILLE`, `POIDS`, `COULEUR`, `HAUTEUR`, `LARGEUR`, `PRIX_PROMOTIONEL`, `SPECIAL_PRICE_START_DATE`, `SPECIAL_PRICE_END_DATE`, `DESCRIPTION`, `APERCU`, `CODEBAR`, `DATE_CREATION`, `DATE_MOD`, `AUTHOR`) VALUES ('9', 'Article 9', '2', '1', '2', '15', 'UGS9', '15', '0', '0', '120', '15', '135', '133.33333333333', '300', '', '8', 'Yellow', '3', '1', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '../modules/nexo/images/produit-9.jpg', '874569', '2016-05-08 05:07:36', '0000-00-00 00:00:00', '2');
INSERT INTO `tendoo_nexo_articles` (`ID`, `DESIGN`, `REF_RAYON`, `REF_SHIPPING`, `REF_CATEGORIE`, `QUANTITY`, `SKU`, `QUANTITE_RESTANTE`, `QUANTITE_VENDU`, `DEFECTUEUX`, `PRIX_DACHAT`, `FRAIS_ACCESSOIRE`, `COUT_DACHAT`, `TAUX_DE_MARGE`, `PRIX_DE_VENTE`, `TAILLE`, `POIDS`, `COULEUR`, `HAUTEUR`, `LARGEUR`, `PRIX_PROMOTIONEL`, `SPECIAL_PRICE_START_DATE`, `SPECIAL_PRICE_END_DATE`, `DESCRIPTION`, `APERCU`, `CODEBAR`, `DATE_CREATION`, `DATE_MOD`, `AUTHOR`) VALUES ('10', 'Article 10', '2', '1', '2', '15', 'UGS10', '15', '0', '0', '120', '15', '135', '133.33333333333', '300', '', '8', 'Yellow', '3', '1', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '../modules/nexo/images/produit-10.jpg', '896547', '2016-05-08 05:07:36', '0000-00-00 00:00:00', '2');
INSERT INTO `tendoo_nexo_articles` (`ID`, `DESIGN`, `REF_RAYON`, `REF_SHIPPING`, `REF_CATEGORIE`, `QUANTITY`, `SKU`, `QUANTITE_RESTANTE`, `QUANTITE_VENDU`, `DEFECTUEUX`, `PRIX_DACHAT`, `FRAIS_ACCESSOIRE`, `COUT_DACHAT`, `TAUX_DE_MARGE`, `PRIX_DE_VENTE`, `TAILLE`, `POIDS`, `COULEUR`, `HAUTEUR`, `LARGEUR`, `PRIX_PROMOTIONEL`, `SPECIAL_PRICE_START_DATE`, `SPECIAL_PRICE_END_DATE`, `DESCRIPTION`, `APERCU`, `CODEBAR`, `DATE_CREATION`, `DATE_MOD`, `AUTHOR`) VALUES ('11', 'Mon article', '1', '2', '1', '400', 'SGE', '400', '0', '0', '65', '5', '70', '46.153846153846', '100', '', '', '', '', '', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', '703488', '2016-05-13 02:21:01', '0000-00-00 00:00:00', '2');
INSERT INTO `tendoo_nexo_articles` (`ID`, `DESIGN`, `REF_RAYON`, `REF_SHIPPING`, `REF_CATEGORIE`, `QUANTITY`, `SKU`, `QUANTITE_RESTANTE`, `QUANTITE_VENDU`, `DEFECTUEUX`, `PRIX_DACHAT`, `FRAIS_ACCESSOIRE`, `COUT_DACHAT`, `TAUX_DE_MARGE`, `PRIX_DE_VENTE`, `TAILLE`, `POIDS`, `COULEUR`, `HAUTEUR`, `LARGEUR`, `PRIX_PROMOTIONEL`, `SPECIAL_PRICE_START_DATE`, `SPECIAL_PRICE_END_DATE`, `DESCRIPTION`, `APERCU`, `CODEBAR`, `DATE_CREATION`, `DATE_MOD`, `AUTHOR`) VALUES ('12', 'Artiicle 11', '1', '1', '1', '400', 'AZDA', '399', '1', '0', '30', '2', '32', '1.09375', '35', '', '', '', '', '', '0', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '', '', '405081', '2016-05-13 02:22:58', '0000-00-00 00:00:00', '2');


#
# TABLE STRUCTURE FOR: tendoo_nexo_categories
#

DROP TABLE IF EXISTS `tendoo_nexo_categories`;

CREATE TABLE `tendoo_nexo_categories` (
  `ID` int(50) NOT NULL AUTO_INCREMENT,
  `NOM` varchar(200) NOT NULL,
  `DESCRIPTION` text NOT NULL,
  `DATE_CREATION` datetime NOT NULL,
  `DATE_MOD` datetime NOT NULL,
  `AUTHOR` int(50) NOT NULL,
  `PARENT_REF_ID` int(50) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `tendoo_nexo_categories` (`ID`, `NOM`, `DESCRIPTION`, `DATE_CREATION`, `DATE_MOD`, `AUTHOR`, `PARENT_REF_ID`) VALUES ('1', 'Men', 'Category for mens items', '2016-05-08 05:07:35', '0000-00-00 00:00:00', '2', '0');
INSERT INTO `tendoo_nexo_categories` (`ID`, `NOM`, `DESCRIPTION`, `DATE_CREATION`, `DATE_MOD`, `AUTHOR`, `PARENT_REF_ID`) VALUES ('2', 'Women', 'Category for women items.', '2016-05-08 05:07:35', '0000-00-00 00:00:00', '2', '0');
INSERT INTO `tendoo_nexo_categories` (`ID`, `NOM`, `DESCRIPTION`, `DATE_CREATION`, `DATE_MOD`, `AUTHOR`, `PARENT_REF_ID`) VALUES ('3', 'Children', 'Category for articles for children.', '2016-05-08 05:07:35', '0000-00-00 00:00:00', '2', '0');
INSERT INTO `tendoo_nexo_categories` (`ID`, `NOM`, `DESCRIPTION`, `DATE_CREATION`, `DATE_MOD`, `AUTHOR`, `PARENT_REF_ID`) VALUES ('4', 'Gifts', 'Category for gift items.', '2016-05-08 05:07:35', '0000-00-00 00:00:00', '2', '0');


#
# TABLE STRUCTURE FOR: tendoo_nexo_clients
#

DROP TABLE IF EXISTS `tendoo_nexo_clients`;

CREATE TABLE `tendoo_nexo_clients` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NOM` varchar(200) NOT NULL,
  `PRENOM` varchar(200) NOT NULL,
  `POIDS` int(11) NOT NULL,
  `TAILLE` int(11) NOT NULL,
  `PREFERENCE` varchar(200) NOT NULL,
  `TEL` varchar(200) NOT NULL,
  `EMAIL` varchar(200) NOT NULL,
  `DESCRIPTION` text NOT NULL,
  `DATE_NAISSANCE` datetime NOT NULL,
  `ADRESSE` text NOT NULL,
  `NBR_COMMANDES` int(11) NOT NULL,
  `OVERALL_COMMANDES` int(11) NOT NULL,
  `DISCOUNT_ACTIVE` int(11) NOT NULL,
  `REF_GROUP` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `tendoo_nexo_clients` (`ID`, `NOM`, `PRENOM`, `POIDS`, `TAILLE`, `PREFERENCE`, `TEL`, `EMAIL`, `DESCRIPTION`, `DATE_NAISSANCE`, `ADRESSE`, `NBR_COMMANDES`, `OVERALL_COMMANDES`, `DISCOUNT_ACTIVE`, `REF_GROUP`) VALUES ('1', 'Client account', '', '0', '0', '', '0', 'user@tendoo.org', '', '0000-00-00 00:00:00', '', '1', '13', '0', '0');
INSERT INTO `tendoo_nexo_clients` (`ID`, `NOM`, `PRENOM`, `POIDS`, `TAILLE`, `PREFERENCE`, `TEL`, `EMAIL`, `DESCRIPTION`, `DATE_NAISSANCE`, `ADRESSE`, `NBR_COMMANDES`, `OVERALL_COMMANDES`, `DISCOUNT_ACTIVE`, `REF_GROUP`) VALUES ('2', 'John Doe', '', '0', '0', '', '0', 'johndoe@tendoo.org', '', '0000-00-00 00:00:00', '', '1', '3', '0', '0');
INSERT INTO `tendoo_nexo_clients` (`ID`, `NOM`, `PRENOM`, `POIDS`, `TAILLE`, `PREFERENCE`, `TEL`, `EMAIL`, `DESCRIPTION`, `DATE_NAISSANCE`, `ADRESSE`, `NBR_COMMANDES`, `OVERALL_COMMANDES`, `DISCOUNT_ACTIVE`, `REF_GROUP`) VALUES ('3', 'Jane Doe', '', '0', '0', '', '0', 'janedoe@tendoo.org', '', '0000-00-00 00:00:00', '', '0', '0', '0', '0');
INSERT INTO `tendoo_nexo_clients` (`ID`, `NOM`, `PRENOM`, `POIDS`, `TAILLE`, `PREFERENCE`, `TEL`, `EMAIL`, `DESCRIPTION`, `DATE_NAISSANCE`, `ADRESSE`, `NBR_COMMANDES`, `OVERALL_COMMANDES`, `DISCOUNT_ACTIVE`, `REF_GROUP`) VALUES ('4', 'Blair Jersyer', '', '0', '0', '', '0', 'carlosjohnsonluv2004@gmail.com', '', '0000-00-00 00:00:00', '', '0', '0', '0', '0');


#
# TABLE STRUCTURE FOR: tendoo_nexo_clients_groups
#

DROP TABLE IF EXISTS `tendoo_nexo_clients_groups`;

CREATE TABLE `tendoo_nexo_clients_groups` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `NAME` varchar(200) NOT NULL,
  `DESCRIPTION` text NOT NULL,
  `DATE_CREATION` datetime NOT NULL,
  `DATE_MODIFICATION` datetime NOT NULL,
  `AUTHOR` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tendoo_nexo_clients_groups` (`ID`, `NAME`, `DESCRIPTION`, `DATE_CREATION`, `DATE_MODIFICATION`, `AUTHOR`) VALUES ('1', 'Sample Groupe', '<p>\r\n	Sample Groupe</p>\r\n', '2016-05-17 22:43:05', '0000-00-00 00:00:00', '2');


#
# TABLE STRUCTURE FOR: tendoo_nexo_commandes
#

DROP TABLE IF EXISTS `tendoo_nexo_commandes`;

CREATE TABLE `tendoo_nexo_commandes` (
  `ID` int(50) NOT NULL AUTO_INCREMENT,
  `TITRE` varchar(200) NOT NULL,
  `DESCRIPTION` varchar(200) NOT NULL,
  `CODE` varchar(250) NOT NULL,
  `REF_CLIENT` int(50) NOT NULL,
  `TYPE` int(50) NOT NULL,
  `DATE_CREATION` datetime NOT NULL,
  `DATE_MOD` datetime NOT NULL,
  `PAYMENT_TYPE` int(50) NOT NULL,
  `AUTHOR` varchar(200) NOT NULL,
  `SOMME_PERCU` int(50) NOT NULL,
  `REMISE` int(50) NOT NULL,
  `RABAIS` int(50) NOT NULL,
  `RISTOURNE` int(50) NOT NULL,
  `TOTAL` int(50) NOT NULL,
  `DISCOUNT_TYPE` varchar(200) NOT NULL,
  `TVA` varchar(200) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

INSERT INTO `tendoo_nexo_commandes` (`ID`, `TITRE`, `DESCRIPTION`, `CODE`, `REF_CLIENT`, `TYPE`, `DATE_CREATION`, `DATE_MOD`, `PAYMENT_TYPE`, `AUTHOR`, `SOMME_PERCU`, `REMISE`, `RABAIS`, `RISTOURNE`, `TOTAL`, `DISCOUNT_TYPE`, `TVA`) VALUES ('2', '', '', 'QQ459P', '1', '3', '2016-05-01 05:10:53', '0000-00-00 00:00:00', '1', '3', '0', '0', '0', '0', '115', 'disable', '3.45');
INSERT INTO `tendoo_nexo_commandes` (`ID`, `TITRE`, `DESCRIPTION`, `CODE`, `REF_CLIENT`, `TYPE`, `DATE_CREATION`, `DATE_MOD`, `PAYMENT_TYPE`, `AUTHOR`, `SOMME_PERCU`, `REMISE`, `RABAIS`, `RISTOURNE`, `TOTAL`, `DISCOUNT_TYPE`, `TVA`) VALUES ('3', '', '', 'LNWVHX', '1', '1', '2016-05-10 05:52:37', '0000-00-00 00:00:00', '1', '3', '300', '0', '0', '0', '215', 'disable', '6.45');
INSERT INTO `tendoo_nexo_commandes` (`ID`, `TITRE`, `DESCRIPTION`, `CODE`, `REF_CLIENT`, `TYPE`, `DATE_CREATION`, `DATE_MOD`, `PAYMENT_TYPE`, `AUTHOR`, `SOMME_PERCU`, `REMISE`, `RABAIS`, `RISTOURNE`, `TOTAL`, `DISCOUNT_TYPE`, `TVA`) VALUES ('4', '', '', '789C6M', '1', '1', '2016-05-02 05:52:56', '0000-00-00 00:00:00', '1', '3', '500', '0', '0', '0', '450', 'disable', '13.5');
INSERT INTO `tendoo_nexo_commandes` (`ID`, `TITRE`, `DESCRIPTION`, `CODE`, `REF_CLIENT`, `TYPE`, `DATE_CREATION`, `DATE_MOD`, `PAYMENT_TYPE`, `AUTHOR`, `SOMME_PERCU`, `REMISE`, `RABAIS`, `RISTOURNE`, `TOTAL`, `DISCOUNT_TYPE`, `TVA`) VALUES ('5', '', '', 'D11VSK', '1', '1', '2016-05-01 05:53:11', '0000-00-00 00:00:00', '1', '4', '250', '0', '0', '0', '240', 'disable', '7.2');
INSERT INTO `tendoo_nexo_commandes` (`ID`, `TITRE`, `DESCRIPTION`, `CODE`, `REF_CLIENT`, `TYPE`, `DATE_CREATION`, `DATE_MOD`, `PAYMENT_TYPE`, `AUTHOR`, `SOMME_PERCU`, `REMISE`, `RABAIS`, `RISTOURNE`, `TOTAL`, `DISCOUNT_TYPE`, `TVA`) VALUES ('6', '', '', 'IC01TU', '1', '3', '2016-05-05 05:53:23', '0000-00-00 00:00:00', '1', '3', '0', '0', '0', '0', '310', 'disable', '9.3');
INSERT INTO `tendoo_nexo_commandes` (`ID`, `TITRE`, `DESCRIPTION`, `CODE`, `REF_CLIENT`, `TYPE`, `DATE_CREATION`, `DATE_MOD`, `PAYMENT_TYPE`, `AUTHOR`, `SOMME_PERCU`, `REMISE`, `RABAIS`, `RISTOURNE`, `TOTAL`, `DISCOUNT_TYPE`, `TVA`) VALUES ('7', '', '', 'Y2NR4P', '2', '1', '2016-05-04 05:56:09', '0000-00-00 00:00:00', '1', '4', '1800', '0', '0', '0', '1695', 'disable', '50.85');
INSERT INTO `tendoo_nexo_commandes` (`ID`, `TITRE`, `DESCRIPTION`, `CODE`, `REF_CLIENT`, `TYPE`, `DATE_CREATION`, `DATE_MOD`, `PAYMENT_TYPE`, `AUTHOR`, `SOMME_PERCU`, `REMISE`, `RABAIS`, `RISTOURNE`, `TOTAL`, `DISCOUNT_TYPE`, `TVA`) VALUES ('9', '', '', 'PTAKRV', '1', '2', '2016-05-01 03:12:59', '2016-05-09 03:48:10', '1', '4', '15', '0', '0', '0', '220', 'disable', '6.6');
INSERT INTO `tendoo_nexo_commandes` (`ID`, `TITRE`, `DESCRIPTION`, `CODE`, `REF_CLIENT`, `TYPE`, `DATE_CREATION`, `DATE_MOD`, `PAYMENT_TYPE`, `AUTHOR`, `SOMME_PERCU`, `REMISE`, `RABAIS`, `RISTOURNE`, `TOTAL`, `DISCOUNT_TYPE`, `TVA`) VALUES ('10', '', '', 'K3MQFZ', '1', '3', '2016-05-09 03:13:51', '0000-00-00 00:00:00', '1', '3', '0', '0', '0', '0', '15', 'disable', '0.45');
INSERT INTO `tendoo_nexo_commandes` (`ID`, `TITRE`, `DESCRIPTION`, `CODE`, `REF_CLIENT`, `TYPE`, `DATE_CREATION`, `DATE_MOD`, `PAYMENT_TYPE`, `AUTHOR`, `SOMME_PERCU`, `REMISE`, `RABAIS`, `RISTOURNE`, `TOTAL`, `DISCOUNT_TYPE`, `TVA`) VALUES ('11', '', '', 'SZTEQU', '1', '3', '2016-05-03 03:15:15', '0000-00-00 00:00:00', '1', '4', '0', '0', '0', '0', '205', 'disable', '6.15');
INSERT INTO `tendoo_nexo_commandes` (`ID`, `TITRE`, `DESCRIPTION`, `CODE`, `REF_CLIENT`, `TYPE`, `DATE_CREATION`, `DATE_MOD`, `PAYMENT_TYPE`, `AUTHOR`, `SOMME_PERCU`, `REMISE`, `RABAIS`, `RISTOURNE`, `TOTAL`, `DISCOUNT_TYPE`, `TVA`) VALUES ('13', '', '', 'CPWUV5', '1', '3', '2016-05-05 03:17:07', '0000-00-00 00:00:00', '1', '2', '0', '0', '0', '0', '150', 'disable', '4.5');
INSERT INTO `tendoo_nexo_commandes` (`ID`, `TITRE`, `DESCRIPTION`, `CODE`, `REF_CLIENT`, `TYPE`, `DATE_CREATION`, `DATE_MOD`, `PAYMENT_TYPE`, `AUTHOR`, `SOMME_PERCU`, `REMISE`, `RABAIS`, `RISTOURNE`, `TOTAL`, `DISCOUNT_TYPE`, `TVA`) VALUES ('14', '', '', '6YN4IN', '1', '1', '2016-05-09 03:33:39', '0000-00-00 00:00:00', '1', '3', '210', '0', '0', '0', '200', 'disable', '6');
INSERT INTO `tendoo_nexo_commandes` (`ID`, `TITRE`, `DESCRIPTION`, `CODE`, `REF_CLIENT`, `TYPE`, `DATE_CREATION`, `DATE_MOD`, `PAYMENT_TYPE`, `AUTHOR`, `SOMME_PERCU`, `REMISE`, `RABAIS`, `RISTOURNE`, `TOTAL`, `DISCOUNT_TYPE`, `TVA`) VALUES ('15', '', '', 'T6P7PD', '1', '1', '2016-05-04 03:47:32', '0000-00-00 00:00:00', '1', '4', '160', '0', '0', '0', '150', 'disable', '4.5');
INSERT INTO `tendoo_nexo_commandes` (`ID`, `TITRE`, `DESCRIPTION`, `CODE`, `REF_CLIENT`, `TYPE`, `DATE_CREATION`, `DATE_MOD`, `PAYMENT_TYPE`, `AUTHOR`, `SOMME_PERCU`, `REMISE`, `RABAIS`, `RISTOURNE`, `TOTAL`, `DISCOUNT_TYPE`, `TVA`) VALUES ('16', '', '', 'QNLTVQ', '2', '1', '2016-05-09 13:50:34', '0000-00-00 00:00:00', '1', '3', '103', '0', '0', '0', '100', 'percent', '3');
INSERT INTO `tendoo_nexo_commandes` (`ID`, `TITRE`, `DESCRIPTION`, `CODE`, `REF_CLIENT`, `TYPE`, `DATE_CREATION`, `DATE_MOD`, `PAYMENT_TYPE`, `AUTHOR`, `SOMME_PERCU`, `REMISE`, `RABAIS`, `RISTOURNE`, `TOTAL`, `DISCOUNT_TYPE`, `TVA`) VALUES ('17', '', '', 'NH9289', '2', '1', '2016-05-08 13:51:36', '2016-05-10 14:02:19', '3', '3', '90', '0', '0', '15', '100', 'percent', '2.55');
INSERT INTO `tendoo_nexo_commandes` (`ID`, `TITRE`, `DESCRIPTION`, `CODE`, `REF_CLIENT`, `TYPE`, `DATE_CREATION`, `DATE_MOD`, `PAYMENT_TYPE`, `AUTHOR`, `SOMME_PERCU`, `REMISE`, `RABAIS`, `RISTOURNE`, `TOTAL`, `DISCOUNT_TYPE`, `TVA`) VALUES ('18', '', '', 'GZY25P', '1', '1', '2016-05-04 23:37:23', '0000-00-00 00:00:00', '1', '2', '999', '0', '0', '0', '150', '', '15');
INSERT INTO `tendoo_nexo_commandes` (`ID`, `TITRE`, `DESCRIPTION`, `CODE`, `REF_CLIENT`, `TYPE`, `DATE_CREATION`, `DATE_MOD`, `PAYMENT_TYPE`, `AUTHOR`, `SOMME_PERCU`, `REMISE`, `RABAIS`, `RISTOURNE`, `TOTAL`, `DISCOUNT_TYPE`, `TVA`) VALUES ('19', '', '', 'D4LSHR', '1', '1', '2016-05-09 02:23:25', '0000-00-00 00:00:00', '1', '2', '40', '0', '0', '0', '35', '', '3.5');


#
# TABLE STRUCTURE FOR: tendoo_nexo_commandes_produits
#

DROP TABLE IF EXISTS `tendoo_nexo_commandes_produits`;

CREATE TABLE `tendoo_nexo_commandes_produits` (
  `ID` int(50) NOT NULL AUTO_INCREMENT,
  `REF_PRODUCT_CODEBAR` varchar(250) NOT NULL,
  `REF_COMMAND_CODE` varchar(250) NOT NULL,
  `QUANTITE` int(11) NOT NULL,
  `PRIX` int(11) NOT NULL,
  `PRIX_TOTAL` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=latin1;

INSERT INTO `tendoo_nexo_commandes_produits` (`ID`, `REF_PRODUCT_CODEBAR`, `REF_COMMAND_CODE`, `QUANTITE`, `PRIX`, `PRIX_TOTAL`) VALUES ('4', '147852', 'LNWVHX', '2', '100', '200');
INSERT INTO `tendoo_nexo_commandes_produits` (`ID`, `REF_PRODUCT_CODEBAR`, `REF_COMMAND_CODE`, `QUANTITE`, `PRIX`, `PRIX_TOTAL`) VALUES ('5', '258741', 'LNWVHX', '1', '15', '15');
INSERT INTO `tendoo_nexo_commandes_produits` (`ID`, `REF_PRODUCT_CODEBAR`, `REF_COMMAND_CODE`, `QUANTITE`, `PRIX`, `PRIX_TOTAL`) VALUES ('6', '147852', '789C6M', '3', '100', '300');
INSERT INTO `tendoo_nexo_commandes_produits` (`ID`, `REF_PRODUCT_CODEBAR`, `REF_COMMAND_CODE`, `QUANTITE`, `PRIX`, `PRIX_TOTAL`) VALUES ('7', '258963', '789C6M', '1', '150', '150');
INSERT INTO `tendoo_nexo_commandes_produits` (`ID`, `REF_PRODUCT_CODEBAR`, `REF_COMMAND_CODE`, `QUANTITE`, `PRIX`, `PRIX_TOTAL`) VALUES ('8', '789654', 'D11VSK', '2', '120', '240');
INSERT INTO `tendoo_nexo_commandes_produits` (`ID`, `REF_PRODUCT_CODEBAR`, `REF_COMMAND_CODE`, `QUANTITE`, `PRIX`, `PRIX_TOTAL`) VALUES ('11', '258741', 'Y2NR4P', '3', '15', '45');
INSERT INTO `tendoo_nexo_commandes_produits` (`ID`, `REF_PRODUCT_CODEBAR`, `REF_COMMAND_CODE`, `QUANTITE`, `PRIX`, `PRIX_TOTAL`) VALUES ('12', '258963', 'Y2NR4P', '11', '150', '1650');
INSERT INTO `tendoo_nexo_commandes_produits` (`ID`, `REF_PRODUCT_CODEBAR`, `REF_COMMAND_CODE`, `QUANTITE`, `PRIX`, `PRIX_TOTAL`) VALUES ('13', '147852', '32Q7OK', '1', '100', '100');
INSERT INTO `tendoo_nexo_commandes_produits` (`ID`, `REF_PRODUCT_CODEBAR`, `REF_COMMAND_CODE`, `QUANTITE`, `PRIX`, `PRIX_TOTAL`) VALUES ('14', '147852', '34A4CR', '1', '100', '100');
INSERT INTO `tendoo_nexo_commandes_produits` (`ID`, `REF_PRODUCT_CODEBAR`, `REF_COMMAND_CODE`, `QUANTITE`, `PRIX`, `PRIX_TOTAL`) VALUES ('15', '147852', '0YC3HR', '1', '100', '100');
INSERT INTO `tendoo_nexo_commandes_produits` (`ID`, `REF_PRODUCT_CODEBAR`, `REF_COMMAND_CODE`, `QUANTITE`, `PRIX`, `PRIX_TOTAL`) VALUES ('16', '147852', 'FKRRF5', '1', '100', '100');
INSERT INTO `tendoo_nexo_commandes_produits` (`ID`, `REF_PRODUCT_CODEBAR`, `REF_COMMAND_CODE`, `QUANTITE`, `PRIX`, `PRIX_TOTAL`) VALUES ('25', '258741', 'K3MQFZ', '1', '15', '15');
INSERT INTO `tendoo_nexo_commandes_produits` (`ID`, `REF_PRODUCT_CODEBAR`, `REF_COMMAND_CODE`, `QUANTITE`, `PRIX`, `PRIX_TOTAL`) VALUES ('28', '147852', 'LSKBCU', '1', '100', '100');
INSERT INTO `tendoo_nexo_commandes_produits` (`ID`, `REF_PRODUCT_CODEBAR`, `REF_COMMAND_CODE`, `QUANTITE`, `PRIX`, `PRIX_TOTAL`) VALUES ('29', '147852', '9XRXBS', '1', '100', '100');
INSERT INTO `tendoo_nexo_commandes_produits` (`ID`, `REF_PRODUCT_CODEBAR`, `REF_COMMAND_CODE`, `QUANTITE`, `PRIX`, `PRIX_TOTAL`) VALUES ('30', '258741', '9XRXBS', '1', '15', '15');
INSERT INTO `tendoo_nexo_commandes_produits` (`ID`, `REF_PRODUCT_CODEBAR`, `REF_COMMAND_CODE`, `QUANTITE`, `PRIX`, `PRIX_TOTAL`) VALUES ('34', '147852', '6YN4IN', '2', '100', '200');
INSERT INTO `tendoo_nexo_commandes_produits` (`ID`, `REF_PRODUCT_CODEBAR`, `REF_COMMAND_CODE`, `QUANTITE`, `PRIX`, `PRIX_TOTAL`) VALUES ('35', '258963', 'T6P7PD', '1', '150', '150');
INSERT INTO `tendoo_nexo_commandes_produits` (`ID`, `REF_PRODUCT_CODEBAR`, `REF_COMMAND_CODE`, `QUANTITE`, `PRIX`, `PRIX_TOTAL`) VALUES ('36', '258741', 'PTAKRV', '2', '15', '30');
INSERT INTO `tendoo_nexo_commandes_produits` (`ID`, `REF_PRODUCT_CODEBAR`, `REF_COMMAND_CODE`, `QUANTITE`, `PRIX`, `PRIX_TOTAL`) VALUES ('37', '369852', 'PTAKRV', '1', '190', '190');
INSERT INTO `tendoo_nexo_commandes_produits` (`ID`, `REF_PRODUCT_CODEBAR`, `REF_COMMAND_CODE`, `QUANTITE`, `PRIX`, `PRIX_TOTAL`) VALUES ('38', '147852', 'QNLTVQ', '1', '100', '100');
INSERT INTO `tendoo_nexo_commandes_produits` (`ID`, `REF_PRODUCT_CODEBAR`, `REF_COMMAND_CODE`, `QUANTITE`, `PRIX`, `PRIX_TOTAL`) VALUES ('41', '147852', 'NH9289', '1', '100', '100');
INSERT INTO `tendoo_nexo_commandes_produits` (`ID`, `REF_PRODUCT_CODEBAR`, `REF_COMMAND_CODE`, `QUANTITE`, `PRIX`, `PRIX_TOTAL`) VALUES ('42', '258963', 'GZY25P', '1', '150', '150');
INSERT INTO `tendoo_nexo_commandes_produits` (`ID`, `REF_PRODUCT_CODEBAR`, `REF_COMMAND_CODE`, `QUANTITE`, `PRIX`, `PRIX_TOTAL`) VALUES ('43', '405081', 'D4LSHR', '1', '35', '35');


#
# TABLE STRUCTURE FOR: tendoo_nexo_fournisseurs
#

DROP TABLE IF EXISTS `tendoo_nexo_fournisseurs`;

CREATE TABLE `tendoo_nexo_fournisseurs` (
  `ID` int(50) NOT NULL AUTO_INCREMENT,
  `NOM` varchar(200) NOT NULL,
  `BP` varchar(200) NOT NULL,
  `TEL` varchar(200) NOT NULL,
  `EMAIL` varchar(200) NOT NULL,
  `DATE_CREATION` datetime NOT NULL,
  `DATE_MOD` datetime NOT NULL,
  `AUTHOR` varchar(200) NOT NULL,
  `DESCRIPTION` text NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `tendoo_nexo_fournisseurs` (`ID`, `NOM`, `BP`, `TEL`, `EMAIL`, `DATE_CREATION`, `DATE_MOD`, `AUTHOR`, `DESCRIPTION`) VALUES ('1', 'Suppliers 1', '', '', 'vendor@tendoo.org', '2016-05-08 05:07:34', '0000-00-00 00:00:00', '2', '');
INSERT INTO `tendoo_nexo_fournisseurs` (`ID`, `NOM`, `BP`, `TEL`, `EMAIL`, `DATE_CREATION`, `DATE_MOD`, `AUTHOR`, `DESCRIPTION`) VALUES ('2', 'Suppliers 2', '', '', 'vendor@tendoo.org', '2016-05-08 05:07:35', '0000-00-00 00:00:00', '2', '');
INSERT INTO `tendoo_nexo_fournisseurs` (`ID`, `NOM`, `BP`, `TEL`, `EMAIL`, `DATE_CREATION`, `DATE_MOD`, `AUTHOR`, `DESCRIPTION`) VALUES ('3', 'Suppliers 3', '', '', 'vendor@tendoo.org', '2016-05-08 05:07:35', '0000-00-00 00:00:00', '2', '');
INSERT INTO `tendoo_nexo_fournisseurs` (`ID`, `NOM`, `BP`, `TEL`, `EMAIL`, `DATE_CREATION`, `DATE_MOD`, `AUTHOR`, `DESCRIPTION`) VALUES ('4', 'Suppliers 4', '', '', 'vendor@tendoo.org', '2016-05-08 05:07:35', '0000-00-00 00:00:00', '2', '');


#
# TABLE STRUCTURE FOR: tendoo_nexo_historique
#

DROP TABLE IF EXISTS `tendoo_nexo_historique`;

CREATE TABLE `tendoo_nexo_historique` (
  `ID` int(50) NOT NULL AUTO_INCREMENT,
  `TITRE` varchar(200) NOT NULL,
  `DETAILS` text NOT NULL,
  `DATE_CREATION` datetime NOT NULL,
  `DATE_MOD` datetime NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `tendoo_nexo_historique` (`ID`, `TITRE`, `DETAILS`, `DATE_CREATION`, `DATE_MOD`) VALUES ('1', 'Réinitialisation de l\'historique', 'L\'utilisateur <strong>blair2004</strong> à supprimé le contenu de l\'historique des activités.', '2016-05-10 18:58:12', '0000-00-00 00:00:00');
INSERT INTO `tendoo_nexo_historique` (`ID`, `TITRE`, `DETAILS`, `DATE_CREATION`, `DATE_MOD`) VALUES ('2', 'Suppression automatique des commandes dévis', 'Les commandes suivantes ont été supprimées automatiquement pour expiration : <ul><li>QQ459P</li><li>IC01TU</li></ul> Les produits ont été restauré dans la boutique.', '2016-05-10 18:58:59', '0000-00-00 00:00:00');
INSERT INTO `tendoo_nexo_historique` (`ID`, `TITRE`, `DETAILS`, `DATE_CREATION`, `DATE_MOD`) VALUES ('3', 'Suppression automatique des commandes dévis', 'Les commandes suivantes ont été supprimées automatiquement pour expiration : <ul><li>QQ459P</li><li>IC01TU</li></ul> Les produits ont été restauré dans la boutique.', '2016-05-10 19:11:41', '0000-00-00 00:00:00');
INSERT INTO `tendoo_nexo_historique` (`ID`, `TITRE`, `DETAILS`, `DATE_CREATION`, `DATE_MOD`) VALUES ('4', 'Suppression automatique des commandes devis', 'Les commandes suivantes ont été supprimées automatiquement pour expiration : <ul><li>QQ459P</li><li>IC01TU</li><li>SZTEQU</li><li>CPWUV5</li></ul> Les produits ont été restauré dans la boutique.', '2016-05-12 18:43:07', '0000-00-00 00:00:00');
INSERT INTO `tendoo_nexo_historique` (`ID`, `TITRE`, `DETAILS`, `DATE_CREATION`, `DATE_MOD`) VALUES ('5', 'Creating a new order', 'Userblair2004 created a new order with the following code:GZY25P', '2016-05-12 23:37:24', '0000-00-00 00:00:00');
INSERT INTO `tendoo_nexo_historique` (`ID`, `TITRE`, `DETAILS`, `DATE_CREATION`, `DATE_MOD`) VALUES ('6', 'Creating a new order', 'Userblair2004 created a new order with the following code:D4LSHR', '2016-05-13 02:23:25', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: tendoo_nexo_paiements
#

DROP TABLE IF EXISTS `tendoo_nexo_paiements`;

CREATE TABLE `tendoo_nexo_paiements` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DESIGN` varchar(200) NOT NULL,
  `DESCRIPTION` text NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `tendoo_nexo_paiements` (`ID`, `DESIGN`, `DESCRIPTION`) VALUES ('1', 'Species', '');
INSERT INTO `tendoo_nexo_paiements` (`ID`, `DESIGN`, `DESCRIPTION`) VALUES ('2', 'Cheque', '');
INSERT INTO `tendoo_nexo_paiements` (`ID`, `DESIGN`, `DESCRIPTION`) VALUES ('3', 'MTN Mobile Money', '');
INSERT INTO `tendoo_nexo_paiements` (`ID`, `DESIGN`, `DESCRIPTION`) VALUES ('4', 'Orange Money:', '');
INSERT INTO `tendoo_nexo_paiements` (`ID`, `DESIGN`, `DESCRIPTION`) VALUES ('5', 'Bank card', '');


#
# TABLE STRUCTURE FOR: tendoo_nexo_premium_factures
#

DROP TABLE IF EXISTS `tendoo_nexo_premium_factures`;

CREATE TABLE `tendoo_nexo_premium_factures` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `INTITULE` varchar(200) NOT NULL,
  `REF` varchar(200) NOT NULL,
  `MONTANT` int(200) NOT NULL,
  `IMAGE` varchar(200) NOT NULL,
  `DESCRIPTION` text NOT NULL,
  `DATE_CREATION` datetime NOT NULL,
  `DATE_MODIFICATION` datetime NOT NULL,
  `AUTHOR` int(11) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tendoo_nexo_premium_factures` (`ID`, `INTITULE`, `REF`, `MONTANT`, `IMAGE`, `DESCRIPTION`, `DATE_CREATION`, `DATE_MODIFICATION`, `AUTHOR`) VALUES ('1', 'zadzadzd', 'zadzadzd', '828414', '', '', '2016-05-17 22:42:47', '0000-00-00 00:00:00', '2');


#
# TABLE STRUCTURE FOR: tendoo_nexo_rayons
#

DROP TABLE IF EXISTS `tendoo_nexo_rayons`;

CREATE TABLE `tendoo_nexo_rayons` (
  `ID` int(50) NOT NULL AUTO_INCREMENT,
  `TITRE` varchar(200) NOT NULL,
  `DESCRIPTION` text NOT NULL,
  `DATE_CREATION` datetime NOT NULL,
  `DATE_MOD` datetime NOT NULL,
  `AUTHOR` int(50) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

INSERT INTO `tendoo_nexo_rayons` (`ID`, `TITRE`, `DESCRIPTION`, `DATE_CREATION`, `DATE_MOD`, `AUTHOR`) VALUES ('1', 'Men', 'Men Radius', '2016-05-08 05:07:35', '0000-00-00 00:00:00', '2');
INSERT INTO `tendoo_nexo_rayons` (`ID`, `TITRE`, `DESCRIPTION`, `DATE_CREATION`, `DATE_MOD`, `AUTHOR`) VALUES ('2', 'Women', 'Women radius', '2016-05-08 05:07:35', '0000-00-00 00:00:00', '2');
INSERT INTO `tendoo_nexo_rayons` (`ID`, `TITRE`, `DESCRIPTION`, `DATE_CREATION`, `DATE_MOD`, `AUTHOR`) VALUES ('3', 'Children', 'Child radius', '2016-05-08 05:07:35', '0000-00-00 00:00:00', '2');
INSERT INTO `tendoo_nexo_rayons` (`ID`, `TITRE`, `DESCRIPTION`, `DATE_CREATION`, `DATE_MOD`, `AUTHOR`) VALUES ('4', 'Gifts', 'Gifts rays', '2016-05-08 05:07:35', '0000-00-00 00:00:00', '2');


#
# TABLE STRUCTURE FOR: tendoo_nexo_types_de_commandes
#

DROP TABLE IF EXISTS `tendoo_nexo_types_de_commandes`;

CREATE TABLE `tendoo_nexo_types_de_commandes` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `DESIGN` varchar(200) NOT NULL,
  `DESCRIPTION` text NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `tendoo_nexo_types_de_commandes` (`ID`, `DESIGN`, `DESCRIPTION`) VALUES ('1', 'Cash', 'For orders that the amount collected is greater than the actual value of the order');
INSERT INTO `tendoo_nexo_types_de_commandes` (`ID`, `DESIGN`, `DESCRIPTION`) VALUES ('2', 'Retainer', 'For orders that the amount collected is greater than 0 and less than the actual value of the order');
INSERT INTO `tendoo_nexo_types_de_commandes` (`ID`, `DESIGN`, `DESCRIPTION`) VALUES ('3', 'Quote', 'For orders the levy is equal to 0');


